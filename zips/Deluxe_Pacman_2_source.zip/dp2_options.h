#pragma once
#include <allegro5/allegro_primitives.h>
#include "dp2_main.h"
#include "dp2_config.h"
#include "a5_error.h"

int options_menu(void);
