#pragma once
#include <allegro5/allegro.h>
#include <stdio.h>

bool a5_screenshot(const char *gamename);
