#define IDI_MYICON 1
