In an age where people get sued for spilling hot coffee on them, I am just making sure I cover myself.

I am releasing this version AS IS... this means is you run it at your own risk.  It ran fine back when I first created it for DOS, but running it under DOSBOX on modern systems is unpredictable and so I am just covering myself. It runs fine for me (DOSBOX & Windows 7 - 64bit).

All material to do with this game is Copyright �2011 by Neil Roy, all rights reserved.  No fee is allowed to be charged in order for you to get this.  It is a free game and MUST remain free or removed from your website.

	Enjoy.
	Neil Roy