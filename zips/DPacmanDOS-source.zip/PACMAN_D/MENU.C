#include "allegro.h"
#include "menu.h"
#include "pacman.h"
#include "pacdat.h"
#include "global.h"
#include "input.h"
#include "jgmod.h"

int dl = 1, pl = 0;
int INPUT_MODE = KEYBOARD;
int SOUND_ENABLED = TRUE;
int MUSIC_ENABLED = TRUE;

void redraw_menu()
{
   int i;

   acquire_screen();
   blit(data[MENU_BACKGROUND].dat, screen, 0, 0, 0, 0, 320, 240);
   for (i=0; i<7; i++)
      draw_sprite(screen, data[MENU1OFF+(i<<1)].dat, 79, i*35);
   release_screen();
}

void update_menu(int select, int oldsel)
{
   acquire_screen();
   draw_sprite(screen, data[MENU1OFF+(oldsel<<1)].dat, 79, oldsel*35);
   draw_sprite(screen, data[MENU1ON+(select<<1)].dat, 79, select*35);
   release_screen();
}

void options()
{
   int c=-1, menu_y = 75;
   FONT *oldfont;
   MENU options_menu[] =
   {
      // (text)              (proc)  (child)  (flags) (dp)
      { "EASY",             NULL,    NULL,    0,    NULL },
      { "MEDIUM",           NULL,    NULL,    0,    NULL },
      { "HARD",             NULL,    NULL,    0,    NULL },
      { "",                 NULL,    NULL,    0,    NULL },
      { "KEYBOARD",         NULL,    NULL,    0,    NULL },
      { "JOYSTICK",         NULL,    NULL,    0,    NULL },
      { "",                 NULL,    NULL,    0,    NULL },
      { "SOUND ON",         NULL,    NULL,    0,    NULL },
      { "SOUND OFF",        NULL,    NULL,    0,    NULL },
      { "",                 NULL,    NULL,    0,    NULL },
      { "MUSIC ON",         NULL,    NULL,    0,    NULL },
      { "MUSIC OFF",        NULL,    NULL,    0,    NULL },
      { NULL,               NULL,    NULL,    0,    NULL }
   };

   oldfont = font;
   font = originalfont;

   options_menu[dl].flags = D_SELECTED;
   if (INPUT_MODE==KEYBOARD) options_menu[4].flags = D_SELECTED;
   else options_menu[5].flags = D_SELECTED;
   if (SOUND_ENABLED) options_menu[7].flags = D_SELECTED;
   else options_menu[8].flags = D_SELECTED;
   if (MUSIC_ENABLED) options_menu[10].flags = D_SELECTED;
   else options_menu[11].flags = D_SELECTED;

   do {
      c = do_menu(options_menu, 100, menu_y);
      if (c>=0 && c<=2) {
         dl=c;
         options_menu[0].flags = 0;
         options_menu[1].flags = 0;
         options_menu[2].flags = 0;
         options_menu[c].flags = D_SELECTED;
         set_mouse_range(120, (menu_y+c*12)+4, 120, (menu_y+c*12)+4);
      }
      if (c==4) {
         INPUT_MODE = KEYBOARD;
         options_menu[4].flags = D_SELECTED;
         options_menu[5].flags = 0;
      }
      if (c==5) {
         INPUT_MODE = JOYSTICK;
         options_menu[4].flags = 0;
         options_menu[5].flags = D_SELECTED;
      }
      if (c==7) {
         SOUND_ENABLED = TRUE;
         options_menu[7].flags = D_SELECTED;
         options_menu[8].flags = 0;
      }
      if (c==8) {
         SOUND_ENABLED = FALSE;
         options_menu[7].flags = 0;
         options_menu[8].flags = D_SELECTED;
      }
      if (c==10) {
         MUSIC_ENABLED = TRUE;
         options_menu[10].flags = D_SELECTED;
         options_menu[11].flags = 0;
         play_mod(data[MOD_MAIN].dat, TRUE);
      }
      if (c==11) {
         MUSIC_ENABLED = FALSE;
         options_menu[10].flags = 0;
         options_menu[11].flags = D_SELECTED;
         stop_mod();
      }
   } while (c!=-1);

   font = oldfont;
}

void help()
{
   int fg=makecol(255,255,0), bg=makecol(0,0,0);
   DIALOG help_dlg[] =
   {  /* (proc)        (x) (y)  (w)  (h) (fg) (bg) (key) (flags) (d1) (d2) (dp)               (dp2)  (dp3) */
      { d_textbox_proc, 0,  0, 320, 240, fg,  bg,   0,    0,      0,   0, data[TEXT_HELP].dat, NULL, NULL },
      { NULL,           0,  0,   0,   0,  0,   0,   0,    0,      0,   0,   NULL,              NULL, NULL }
   };

   set_mouse_range(320, 240, 320, 240);
   do_dialog(help_dlg, 0);
   redraw_menu();
}

void aboot()
{
   int fg=makecol(255,255,0), bg=makecol(0,0,0);
   DIALOG aboot_dlg[] =
   {  /* (proc)        (x) (y)  (w)  (h) (fg) (bg) (key) (flags) (d1) (d2) (dp)                (dp2)  (dp3) */
      { d_textbox_proc, 0,  0, 320, 240, fg,  bg,   0,    0,      0,   0, data[TEXT_ABOUT].dat, NULL, NULL },
      { NULL,           0,  0,   0,   0,  0,   0,   0,    0,      0,   0,   NULL,               NULL, NULL }
   };

   set_mouse_range(320, 240, 320, 240);
   do_dialog(aboot_dlg, 0);
   redraw_menu();
}

void credits()
{
   int fg=makecol(255,255,0), bg=makecol(0,0,0);
   DIALOG credits_dlg[] =
   {  /* (proc)        (x) (y)  (w)  (h) (fg) (bg) (key) (flags) (d1) (d2) (dp)                  (dp2)  (dp3) */
      { d_textbox_proc, 0,  0, 320, 240, fg,  bg,   0,    0,      0,   0, data[TEXT_CREDITS].dat, NULL, NULL },
      { NULL,           0,  0,   0,   0,  0,   0,   0,    0,      0,   0,   NULL,                 NULL, NULL }
   };

   set_mouse_range(320, 240, 320, 240);
   do_dialog(credits_dlg, 0);
   redraw_menu();
}

int main_menu()
{
   int i, k, done = -1, select = 0, oldsel = 0;
   BITMAP *bmp = create_bitmap(SCREEN_W, SCREEN_H);

   if (bmp==NULL) {
      allegro_message("Error creating bitmap (bmp) in main_menu.\n%s\n",
                       allegro_error);
      exit(1);
   }

   clear(bmp);


   blit(data[MENU_BACKGROUND].dat, bmp, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
   for (i=0; i<7; i++)
      draw_sprite(bmp, data[MENU1OFF+(i<<1)].dat, 79, i*35);
   acquire_screen();
   blit(bmp, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
   release_screen();

   /* selection takes place here */
   do {
      clear_keybuf();
      update_menu(select, oldsel);
      rest(250);
      while(!keypressed()) input_joycheck();
      oldsel = select;
      k = readkey() >> 8;
      if (k==KEY_UP) {
         select--;
         if (select < 0) select = 6;
         if (SOUND_ENABLED) play_sample(data[SS_PILL].dat, 255, 128, 3000, 0);
      }
      if (k==KEY_DOWN) {
         select++;
         if (select > 6) select = 0;
         if (SOUND_ENABLED) play_sample(data[SS_PILL].dat, 255, 128, 3000, 0);
      }
      if (k==KEY_ESC) { select=6; update_menu(select, oldsel); done=6; }
      if (k==KEY_ENTER) {
         if (select==1) pl=1;
         done=select;
         if (select==2) options(); // options (difficulty level & video mode)
         if (select==3) help();    // help
         if (select==4) aboot();   // about ;)
         if (select==5) credits(); // credits
      }
   } while(done!=0 && done!=1 && done!=6);

   /* destroy bitmap(s) and return */
   if (bmp!=NULL) destroy_bitmap(bmp);
   return done;
}

