#ifndef nr_pacman_h
#define nr_pacman_h

void init();
void init_variables();
void EndGame();
void drawmap();
char *fixscore(unsigned int s);
void float_points(int value, int x, int y);
void reset_active_tools();
void update_screen();
int loadmap_pack(char *file);
int loadmap_disk(char *file);
void save_screen();
void move_players();
void Win();
void Dead();
void title();
void move_dir(int d, int i);
void move_ghosts();
void check_collision();

extern FONT *tinyfont, *redfont, *greenfont, *yellowfont, *originalfont;
extern BITMAP *bmp, *pacmap, *s, *spr;
extern DATAFILE *data;
extern int done, game_over, back1, back2, cplayer;

typedef struct PLAYER
{
   int lives;                    // Number of lives the player has left
   unsigned int score;           // Current score
   unsigned int oldscore;        // used to see how much the players score
                                 // has changed
   int dead;                     // is player dead (should probably use a
                                 // .state variable)
   int level;                    // current level player is on
   int oldlevel;                 // the last level the player came from
   int pvalue;                   // the current value of pickups
   unsigned short pills;         // the number of pills left on the map
   unsigned int map[15][21];     // the current map data
   unsigned int tmap[15][21];    // used when pills are converted to diamonds
                                 // to store a copy of the map.
   int extra;                    // What EXTRA letters does the player have,
                                 // this uses bits to represent each letter.
   int wrap;                     // has the player done all the levels?
} PLAYER;
extern PLAYER player[2];

typedef struct PACMAN
{
   int img[20];      // Pacman animation images
   int cur_img;      // the current pacman image from above
   int inc;          // +1 increment and -1 for opening/closing mouth
   int mx, my;       // Current map co-ordinate pacman is in
   int x, y;         // pacman screen co-ordinates
   int ox, oy;       // old screen co-ordinates
   int xd, yd;       // direction pacman is facing x+/- y+/-
   int dead;         // is pacman dead
   int img_delay;    // delay between animation images
   int cntr;         // delay counter (if (cntr%img_delay==0) update anim)
                     // I would like to install a timer interrupt in future
                     // projects rather than this method.
} PACMAN;
extern PACMAN pacman;
extern volatile float game_time;

typedef struct POINT
{
	int x, y;      // screen co-ordinates points initially appear at
	int colour;    // colour of text
	int delay;     // delay between movement of points
	int counter;   // when counter = delay, move points up screen
	int value;     // value of points to be displayed
	int move;      // how many pixels should we move the points
	int moved;     // how many pixels have the points moved
} POINT;

typedef struct PICKUP
{
	int current;         // current pickup number (0 to max)
	int time;            // length of time pickup has been on screen
	int maxtime;         // max time pickup should stay on screen
	int x, y;            // on screen co-ordinates
	int mx, my;          // map co-ordinates
	int active;          // is pickup currently on screen?
	int cntr;            // delay counter
	int wait;            // time between pickups (1/60th sec)
} PICKUP;

typedef struct TOOL
{
	int current;         // current tool number (0 to max)
	int time;            // length of time tool has been on screen
	int maxtime;         // max time tool should stay on screen
	int x, y;            // on screen co-ordinates
	int mx, my;          // map co-ordinates
	int active;          // is tool currently on screen?
	int cntr;            // delay counter
	int wait;            // time between tools (1/60th sec)
} TOOL;

typedef struct GHOST
{
	int img[8];          // image numbers that make up the ghost animation
	int mx, my;          // current map cell ghost is in
	int x, y;            // current screen co-ordinates
	int ox, oy;          // old screen co-ordinates
	int xd, yd;          // direction ghost is travelling in
	int cur_img;         // current image
	int dead;            // ghost dead flag
	int img_delay;       // delay between animation images
	int cntr;            // delay counter
	int scared;          // ghost scared (blue) flag
	int inc;             // animation direction (+1 or -1)
	int stimer;          // scared timer
	int stime;           // how long to stay scared
	int scntr;           // scared counter
	int eyes;            // direction eyes are pointing
	int frozen;          // is ghost frozen?  TRUE or FALSE
} GHOST;

#endif
