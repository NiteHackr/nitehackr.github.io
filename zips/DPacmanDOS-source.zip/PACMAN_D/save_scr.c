#include <stdio.h>
#include <string.h>
#include <allegro.h>
#include "pacman.h"

// Save a screen shot
void save_screen() {
   BITMAP *savebmp;
   PALETTE savepal;
   char text[256];
   static int dump = 0;

   sprintf(text, "capt%04d.pcx", dump);
   dump++;

   get_palette(savepal);
   savebmp = create_sub_bitmap(screen, 0, 0, SCREEN_W, SCREEN_H);
   scare_mouse();
   blit(screen, savebmp, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
   unscare_mouse();
   save_bitmap(text, savebmp, savepal);
   destroy_bitmap(savebmp);

   update_screen();
}
