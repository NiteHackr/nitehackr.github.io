#ifndef nr_main_menu_h
   #define KEYBOARD 1
   #define JOYSTICK 2

   int main_menu(void);

   extern int dl, pl, vm;
   extern int INPUT_MODE, SOUND_ENABLED, MUSIC_ENABLED;
#endif
