/* global.c
 *    These are global variables for things like screen size etc...
 */

#include <allegro.h>

const int screen_width  = 320,
          screen_height = 240,
          screen_depth = 8;

const int map_width = 320,
          map_height = 225;
