/*������������������������������������������������������������������������ͻ
  �Program: Deluxe Pacman PC                                               �
  �Author: Neil A. Roy                                                     �
  �Description: This game was written as a PC version of Deluxe Pacman for �
  �             the Amiga, but with my own touches, graphics etc.  This was�
  �             not meant to be a clone but merely draws inspiration from  �
  �             the Amiga game of the same name.                           �
  ������������������������������������������������������������������������ͼ*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <conio.h>
#include "allegro.h"
#include "jgmod.h"
#include "pacdat.h"
#include "hiscore.h"
#include "save_scr.h"
#include "global.h"
#include "error.h"
#include "pacman.h"
#include "menu.h"
#include "input.h"

#define MAX_TOOLS    (TOOLZZZ-TOOL000)

const char *NAME = "Deluxe Pacman";
const char *VERSION = "1.02";
const char *MAP_ID = "pacmap";      // Map ID
const unsigned char MAP_VER = 5;    // Map version
const int RIGHT = 0;
const int DOWN = 1;
const int LEFT = 2;
const int UP = 3;

DATAFILE *data=NULL;
BITMAP *bmp=NULL, *pacmap=NULL, *s=NULL, *spr=NULL;
FONT *tinyfont=NULL, *redfont=NULL, *greenfont=NULL, *yellowfont=NULL,
	  *originalfont=NULL;

int use_retrace_proc = FALSE;
char path[256], text[256], temp[9];
char mapName[256];
int game_over;
int exit_game;
int done;
int players = 1;
int cplayer = 0;
int difficulty = 1;
unsigned int hiscore, ghostscore;
int back1=-1, back2=-1;
volatile int frame_count, fps;
volatile float game_time;
float speed = 1;  // initial game speed (slow = 1.2, fast = .8)
int switched_in = FALSE;
int tool_inuse[MAX_TOOLS];

// packfile password (subtract 17 from each ascii value)
char pfpw[] = "EHDFAGDGI";

POINT point[32];
PLAYER player[2];
PICKUP pickup = { 0 , 0, 150, 150, 180, 10, 11, FALSE, 0, 1500 };
TOOL tool = { 0 , 0, 150, 150, 180, 10, 11, FALSE, 0, 1500 };
PACMAN pacman = {{PACMAN01, PACMAN02, PACMAN03, PACMAN04,
                  PACMAN05, PACMAN06, PACMAN07, PACMAN08,
                  PACMAN09, PACMAN10, PACMAN11, PACMAN12,
                  PACMAN13, PACMAN14, PACMAN15, PACMAN16,
                  PACMAN17, PACMAN18, PACMAN19, PACMAN20},
                  1, 1, 10, 11, 150, 180, 150, 180, 1, 0,
                  FALSE, 3, 0};

GHOST ghost[4] = {{{GHOST_R1, GHOST_R2, GHOST_R3, GHOST_R4,
                    GHOST_B1, GHOST_B2, GHOST_B3, GHOST_B4},
                    9, 9, 135, 150, 135, 150, 1, 0, 0, FALSE,
                    2, 0, 0, 1, 0, 180, 0, EYES6, FALSE},
                  {{GHOST_G1, GHOST_G2, GHOST_G3, GHOST_G4,
                    GHOST_B1, GHOST_B2, GHOST_B3, GHOST_B4},
                    9, 9, 135, 150, 135, 150, -1, 0, 1, FALSE,
                    2, 0, 0, 1, 0, 180, 0, EYES4, FALSE},
                  {{GHOST_P1, GHOST_P2, GHOST_P3, GHOST_P4,
                    GHOST_B1, GHOST_B2, GHOST_B3, GHOST_B4},
                    11, 9, 165, 150, 135, 150, 1, 0, 2, FALSE,
                    2, 0, 0, 1, 0, 180, 0, EYES6, FALSE},
                  {{GHOST_Y1, GHOST_Y2, GHOST_Y3, GHOST_Y4,
                    GHOST_B1, GHOST_B2, GHOST_B3, GHOST_B4},
                    11, 9, 165, 150, 135, 150, -1, 0, 3, FALSE,
                    2, 0, 0, 1, 0, 180, 0, EYES4, FALSE}};

struct dir_typ {
   int b;         // path blocked flag (TRUE or FALSE)
	int x, y;
} dir[4] = {{FALSE, 1, 0},   // dir[RIGHT]
            {FALSE, 0, 1},   // dir[DOWN]
            {FALSE,-1, 0},   // dir[LEFT]
            {FALSE, 0,-1}};  // dir[UP]

// *************  DIRTY RECTANGLES *************
/* dirty rectangle list */
typedef struct DIRTY_RECT
{
	int x, y, w, h;
} DIRTY_RECT;

typedef struct DIRTY_LIST
{
	int count;
	DIRTY_RECT rect[1024];
} DIRTY_LIST;

DIRTY_LIST dirty, old_dirty;

/* qsort() callback for sorting the dirty rectangle list */
int rect_cmp(const void *p1, const void *p2)
{
	DIRTY_RECT *r1 = (DIRTY_RECT *)p1;
	DIRTY_RECT *r2 = (DIRTY_RECT *)p2;

	return (r1->y - r2->y);
}

/* adds a new screen area to the dirty rectangle list */
void add_to_list(DIRTY_LIST *list, int x, int y, int w, int h)
{
	list->rect[list->count].x = x;
	list->rect[list->count].y = y;
	list->rect[list->count].w = w;
	list->rect[list->count].h = h;
	list->count++; 
}
// ********************************************


// timer callback for controlling the game speed
void game_timer(void)
{
	game_time++;
} END_OF_FUNCTION(game_timer);

// timer callback for measuring the frames per second
void fps_proc(void)
{
	fps = frame_count;
	frame_count = 0;
} END_OF_FUNCTION(fps_proc);

// Initialize Allegro, sound etc...
void init()
{
	int i;

	allegro_init();
   install_timer();
   input_init();
	reserve_voices(16, -1);
	use_retrace_proc = timer_is_using_retrace();

	LOCK_VARIABLE(game_time);
	LOCK_FUNCTION(game_timer);

	LOCK_VARIABLE(frame_count);
	LOCK_VARIABLE(fps);
	LOCK_FUNCTION(fps_proc);

	set_color_depth(screen_depth);

	if (install_sound(DIGI_AUTODETECT, MIDI_AUTODETECT, NULL)<0)
		error("Error initializing sound card.", allegro_error);

	if (install_mod(4)<0)
		error("Error setting digi voices.", NULL);

	if (set_gfx_mode(GFX_AUTODETECT, screen_width, screen_height, 0, 0)<0)
		error ("Error setting graphics mode.", allegro_error);

	set_color_conversion(COLORCONV_TOTAL); // convert everything

	for (i=0; i<9; i++) pfpw[i]-=17;   // decode password
	packfile_password(pfpw);
	data = load_datafile(text);
	packfile_password(NULL);
	if (!data)
		error("Error loading pacman.dat!", NULL);

	set_pallete(data[PAL_DEFAULT].dat);

	clear(screen);

	originalfont = font;
	font = data[FONT_WHITE].dat;
	redfont = data[FONT_RED].dat;
	greenfont = data[FONT_GREEN].dat;
	yellowfont = data[FONT_YELLOW].dat;
   tinyfont = data[FONT_TINY].dat;

	bmp=create_bitmap(screen_width, screen_height);
	pacmap=create_bitmap(map_width, map_height);
	if (!bmp || !pacmap)
		error ("Couldn't create bitmaps.", NULL);
	clear(bmp);

	srand((unsigned)time(NULL));  // seed the random number generator
	text_mode(0);
	init_hiscore();

	set_display_switch_mode(SWITCH_PAUSE);
}

// Initialize Variables
void init_variables()
{
	int i;

	pacman.cur_img=1;  pacman.inc=1;
	pacman.x=150;      pacman.y=180;
	pacman.ox=150;     pacman.oy=180;
	pacman.xd=1;       pacman.yd=0;
	pacman.dead=FALSE; pacman.cntr=0;

	ghost[0].x = 129; ghost[0].eyes = EYES6;
	ghost[0].xd = 1; ghost[0].yd = 0;
	ghost[0].frozen = FALSE;
	ghost[1].x = 142; ghost[1].eyes = EYES4;
	ghost[1].xd = 1; ghost[1].yd = 0;
	ghost[1].frozen = FALSE;
	ghost[2].x = 154; ghost[2].eyes = EYES6;
	ghost[2].xd = -1; ghost[2].yd = 0;
	ghost[2].frozen = FALSE;
	ghost[3].x = 167; ghost[3].eyes = EYES4;
	ghost[3].xd = -1; ghost[3].yd = 0;

	for (i=0; i<=3; i++)
	{
		ghost[i].y=150;
		ghost[i].cur_img=0;
		ghost[i].dead=FALSE;
		ghost[i].cntr=0;
		ghost[i].scared=0;
		ghost[i].inc=1;
		ghost[i].stimer=0;
		ghost[i].frozen=FALSE;
	}

	for (i=0; i<=15; i++)
	{
		point[i].x = 0;
		point[i].y = 0;
		point[i].colour = makecol(255, 255, 255);
		point[i].delay = 4;
		point[i].counter = 0;
		point[i].value = 0;
		point[i].move = 16;
		point[i].moved = 0;
	}

	for (i=0; i<MAX_TOOLS; i++)
	{
      tool_inuse[i] = FALSE;
	}

	player[0].dead = FALSE;
	player[1].dead = FALSE;

	game_over = exit_game = done = FALSE;
	ghostscore = 200;
	frame_count = fps = 0;
}

// Cleans up before exiting game
void EndGame()
{
	remove_int(fps_proc);
	if (use_retrace_proc)
		retrace_proc = NULL;
	else
		remove_int(game_timer);
	if (bmp != NULL) destroy_bitmap(bmp);
	if (pacmap != NULL) destroy_bitmap(pacmap);
	unload_datafile(data);
	shutdown_hiscore();
	set_gfx_mode(GFX_TEXT,0,0,0,0);
	exit(1);
}

// Draw Map
void drawmap()
{
	int x, y;

	clear(bmp);
	clear(pacmap);
	clear(screen);

	for (y=0; y<=14; y++)
	{
		for (x=0; x<=20; x++)
		{
         if (player[cplayer].map[y][x] >= A99LINEZZ)
				player[cplayer].map[y][x] = A000BLANK;
			blit(data[player[cplayer].map[y][x]].dat, pacmap,
				0, 0, x*15, y*15, 15, 15);
		}
	}
	blit(pacmap, bmp, 0, 0, 0, 15, map_width, map_height);
	blit(pacmap, screen, 0, 0, 0, 15, map_width, map_height);
}

// Show a tiny floating score on screen
void float_points(int value, int x, int y)
{
	int i;

	for (i=0; i<32; i++)
	{
		if (point[i].value == 0)
		{
			point[i].value = value;
			point[i].x = x;
			point[i].y = y;
			point[i].counter = retrace_count;
			point[i].colour = makecol(255, 255, 255);
			i = 32;
		}
	}
}

void reset_active_tools()
{
	int i, x, y;

	tool.active = FALSE;

	for (i=0; i<MAX_TOOLS; i++)
      tool_inuse[i] = FALSE;

	for (y=0; y<15; y++)
		for (x=0; x<22; x++)
         if (player[cplayer].map[y][x]==TOOL000)
				player[cplayer].map[y][x]=player[cplayer].tmap[y][x];

	for (i=0; i<4; i++) ghost[i].frozen = FALSE;

	player[cplayer].map[11][10] = A000BLANK;

	drawmap();
}

// Update the screen
void update_screen()
{
	int i, r, y2, bar;
	int pacimage = pacman.img[pacman.cur_img];
	int ghostimg[4];
	static int heart[3] = {HEART1, HEART2, HEART3};
	static int beat = 0, beat_inc = 1, beat_cntr = 0;
	BITMAP *s;

   acquire_screen();
	for (i=0; i<dirty.count; i++)
	{
		if ((dirty.rect[i].w == 1) && (dirty.rect[i].h == 1))
		{
			putpixel(bmp, dirty.rect[i].x, dirty.rect[i].y, 
			getpixel(pacmap, dirty.rect[i].x, dirty.rect[i].y-15));
		}
		else
		{
			blit(pacmap, bmp, dirty.rect[i].x, dirty.rect[i].y-15, 
				 dirty.rect[i].x, dirty.rect[i].y, 
				 dirty.rect[i].w, dirty.rect[i].h);
		}
	}
	release_screen();
	old_dirty = dirty;
	dirty.count = 0;

	text_mode(0);

	for (i=0; i<=3; i++)
	{
		ghostimg[i] = ghost[i].img[ghost[i].cur_img];
	}

	// pickup or tool selection
	if (!pickup.active && !tool.active && !(retrace_count%pickup.wait) &&
		 !(retrace_count%tool.wait))
	{

      r = rand() % 2;  // activate pickup or tool?
		if (DIAMONDS||EXTRA_E||EXTRA_X||EXTRA_T||EXTRA_R||EXTRA_A) r = 0;

		reset_active_tools();
		tool.active = FALSE; pickup.active = FALSE;

		if (r==0)      // activate tool!
		{
			tool.active = TRUE;
         tool.current = rand() % MAX_TOOLS;
         if (DIAMONDS) { tool.current = 0; DIAMONDS = FALSE; }
			if (EXTRA_A) { tool.current = 1; EXTRA_A = FALSE; }
			if (EXTRA_E) { tool.current = 2; EXTRA_E = FALSE; }
			if (EXTRA_R) { tool.current = 3; EXTRA_R = FALSE; }
			if (EXTRA_T) { tool.current = 4; EXTRA_T = FALSE; }
			if (EXTRA_X) { tool.current = 5; EXTRA_X = FALSE; }
         if ((tool.current>=1 && tool.current<=5) &&
             (player[cplayer].extra & (int)pow(2,tool.current-1)))
			{
            r=1;
            tool.active = FALSE;
			}
         else {
            tool.time = 0;
            spr = data[TOOL000+tool.current].dat;
         }
		}
		if (r==1)      // activate pickup!
		{
			pickup.active = TRUE;
         pickup.current = rand() % (PU_ZZZ-PU_APPLE);
			pickup.time = 0;
			spr = data[PU_APPLE+pickup.current].dat;
		}
      if (SOUND_ENABLED) play_sample(data[SS_PICKUP].dat, 255, 128, 1000, 0);
	}

	// pickup active checks
   if (pickup.active && (pickup.time >= pickup.maxtime))
	{
		pickup.active = FALSE;
		player[cplayer].map[pickup.my][pickup.mx] = A000BLANK;
	}
	if (retrace_count - pickup.cntr>=5)
	{
		pickup.time++;
		pickup.cntr = retrace_count;
	}
	if (pickup.active)
	{
		draw_sprite(bmp, spr, pickup.mx*15+7-(spr->w>>1),
			pickup.my*15+22-(spr->h>>1));
		add_to_list(&dirty, pickup.mx*15+7-(spr->w>>1),
			pickup.my*15+22-(spr->h>>1), spr->w, spr->h);
		player[cplayer].map[pickup.my][pickup.mx] = (PU_APPLE+pickup.current);
	}

	// tool active checks
	if (tool.active && (tool.time >= tool.maxtime))
	{
		tool.active = FALSE;
		player[cplayer].map[tool.my][tool.mx] = A000BLANK;
	}
	if (retrace_count - tool.cntr>=5)
	{
		tool.time++;
		tool.cntr = retrace_count;
	}
	if (tool.active)
	{
		draw_sprite(bmp, spr, tool.mx*15+7-(spr->w>>1),
			tool.my*15+22-(spr->h>>1));
		add_to_list(&dirty, tool.mx*15+7-(spr->w>>1),
			tool.my*15+22-(spr->h>>1), spr->w, spr->h);
      player[cplayer].map[tool.my][tool.mx] = (TOOL000 + tool.current);
	}


	// update the heart beat
	if (retrace_count - beat_cntr>=5)
	{
		beat+=beat_inc;
		beat_cntr=retrace_count;
	}

	if (beat==2) beat_inc=-1;
	if (beat==0) beat_inc=1;

	// Draw heart(s)
	if (player[cplayer].lives>1)
	{
		for (i=1; i<player[cplayer].lives; i++)
		{
			blit(data[HEART1].dat, bmp, 0, 0, 63-8*i, 231, 7, 7);
			add_to_list(&dirty, 63-8*i, 231, 7, 7);
		}
	}

	if (player[cplayer].extra & 1) {
		s=data[SM_EXTRA_A].dat;
		draw_sprite(bmp, s, 106-(s->w>>1), 234-(s->h>>1));
		add_to_list(&dirty, 106-(s->w>>1), 234-(s->h>>1), s->w, s->h);
	}
	if (player[cplayer].extra & 2) {
		s=data[SM_EXTRA_E].dat;
		draw_sprite(bmp, s, 74-(s->w>>1), 234-(s->h>>1));
		add_to_list(&dirty, 74-(s->w>>1), 234-(s->h>>1), s->w, s->h);
	}
	if (player[cplayer].extra & 4) {
		s=data[SM_EXTRA_R].dat;
		draw_sprite(bmp, s, 98-(s->w>>1), 234-(s->h>>1));
		add_to_list(&dirty, 98-(s->w>>1), 234-(s->h>>1), s->w, s->h);
	}
	if (player[cplayer].extra & 8) {
		s=data[SM_EXTRA_T].dat;
		draw_sprite(bmp, s, 90-(s->w>>1), 234-(s->h>>1));
		add_to_list(&dirty, 90-(s->w>>1), 234-(s->h>>1), s->w, s->h);
	}
	if (player[cplayer].extra & 16) {
		s=data[SM_EXTRA_X].dat;
		draw_sprite(bmp, s, 82-(s->w>>1), 234-(s->h>>1));
		add_to_list(&dirty, 82-(s->w>>1), 234-(s->h>>1), s->w, s->h);
	}

	if (player[cplayer].lives>0 && pacman.dead==FALSE)
	{
		blit(data[heart[beat]].dat, bmp, 0, 0,
			63-8*player[cplayer].lives, 231, 7, 7);
		add_to_list(&dirty, 63-8*player[cplayer].lives, 231, 7, 7);
	}

	// Draw PACMAN
	s = data[pacimage].dat;
	if (pacman.xd==1)          // right
	{
		draw_sprite(bmp, s, pacman.x-5, pacman.y-5);
		add_to_list(&dirty, pacman.x-5, pacman.y-5, s->w, s->h);
	}
	else if (pacman.yd==1)     // down
	{
		rotate_sprite(bmp, s, pacman.x-5, pacman.y-5, itofix(64));
		add_to_list(&dirty, pacman.x-5, pacman.y-5, s->w, s->h);
	}
	else if (pacman.xd==-1)    // left
	{
		draw_sprite_h_flip(bmp, s, pacman.x-5, pacman.y-5);
		add_to_list(&dirty, pacman.x-5, pacman.y-5, s->w, s->h);
	}
	else if (pacman.yd==-1)    // up
	{
		rotate_sprite(bmp, s, pacman.x-5, pacman.y-5, itofix(192));
		add_to_list(&dirty, pacman.x-5, pacman.y-5, s->w, s->h);
	}

	// if shield active or GODMODE is on, draw shield.
   if ((GODMODE || tool_inuse[10]) && !pacman.dead) {
		circle(bmp, pacman.x+7, pacman.y+7, s->w>>1,
				 makecol(rand()%127+128, rand()%127+128, rand()%127+128));
	}

	// Draw Ghosts (if they have not been eaten)
	if (pacman.dead==FALSE)
	{
		for (i=0; i<=3; i++)
		{
			if (ghost[i].dead==FALSE)
			{
				if (ghost[i].scared==TRUE && (ghost[i].stime-ghost[i].stimer)<=60)
				{
					if (ghost[i].stimer%2)
					{
						s = data[ghost[i].img[1]].dat;
						draw_sprite(bmp, s, ghost[i].x-5, ghost[i].y-5);
						add_to_list(&dirty, ghost[i].x-5, ghost[i].y-5, s->w, s->h);
					}
					else
					{
						s = data[ghostimg[i]].dat;
						draw_sprite(bmp, s, ghost[i].x-5, ghost[i].y-5);
						add_to_list(&dirty, ghost[i].x-5, ghost[i].y-5, s->w, s->h);
					}
				}
				else
				{
					s = data[ghostimg[i]].dat;
					draw_sprite(bmp, s, ghost[i].x-5, ghost[i].y-5);
					add_to_list(&dirty, ghost[i].x-5, ghost[i].y-5, s->w, s->h);
				}
			}
			// Draw Ghost's eyes (if they are not scared)
			if (ghost[i].scared==FALSE || ghost[i].dead==TRUE)
			{
				if (ghost[i].x < pacman.x-15)
				{
					if (ghost[i].y > (pacman.y+15)) ghost[i].eyes = EYES9;
					else if (ghost[i].y < (pacman.y-15)) ghost[i].eyes = EYES3;
					else ghost[i].eyes = EYES6;
				}
				else if (ghost[i].x > pacman.x+15)
				{
					if (ghost[i].y > (pacman.y+15)) ghost[i].eyes = EYES7;
					else if (ghost[i].y < (pacman.y-15)) ghost[i].eyes = EYES1;
					else ghost[i].eyes = EYES4;
				}
				else if (ghost[i].y > pacman.y) ghost[i].eyes = EYES8;
				else if (ghost[i].y < pacman.y) ghost[i].eyes = EYES2;
				s = data[ghost[i].eyes].dat;
				draw_sprite(bmp, s, ghost[i].x-5, ghost[i].y-5);
				add_to_list(&dirty, ghost[i].x-5, ghost[i].y-5, s->w, s->h);
			}
		}
	}

	// update the score
	if (player[cplayer].oldscore != 0)
	{
		if (player[cplayer].score != 0)
		{
			// Player gets free man at 50000, 100000 and every 100000 after
			if (player[cplayer].oldscore<50000 && player[cplayer].score >= 50000)
			{
				if (player[cplayer].lives < 5) player[cplayer].lives++;
            if (SOUND_ENABLED) play_sample(data[SS_ALRIGHT].dat, 255,
					(int)((pacman.x+12)/1.26), 1000, 0);
			}
			else if (player[cplayer].oldscore > 50000)
			{
				if ((int)(player[cplayer].oldscore/100000) !=
					(int)(player[cplayer].score/100000))
				{
					if (player[cplayer].lives < 5)
					{
						player[cplayer].lives++;
                  if (SOUND_ENABLED) play_sample(data[SS_ALRIGHT].dat, 255,
							(int)((pacman.x+12)/1.26), 1000, 0);
					}
				}
			}
		}
	}
	if (!CHEAT)
	{
		// Only update the hiscore if cheats are disabled
		if (player[0].score > hiscore) hiscore = player[0].score;
		if (player[1].score > hiscore) hiscore = player[1].score;
	}


	textout(bmp, font, "1UP", 6, 0, -1);
	add_to_list(&dirty, 6, 0, text_length(font, "1UP"), text_height(font));
	sprintf(text, "%08d", player[0].score);
	textout(bmp, redfont, text, 30, 0, -1);
	add_to_list(&dirty, 30, 0,
		text_length(redfont, text), text_height(redfont));

	textout(bmp, font, "HI", 118, 0, -1);
	add_to_list(&dirty, 118, 0, text_length(font, "HI"), text_height(font));
	sprintf(text, "%08d", hiscore);
	textout(bmp, greenfont, text, 134, 0, -1);
	add_to_list(&dirty, 134, 0,
		text_length(greenfont, text), text_height(greenfont));

	textout(bmp, font, "2UP", 222, 0, -1);
	add_to_list(&dirty, 222, 0, text_length(font, "2UP"), text_height(font));
	sprintf(text, "%08d", player[1].score);
	textout(bmp, yellowfont, text, 246, 0, -1);
	add_to_list(&dirty, 246, 0,
		text_length(yellowfont, text), text_height(yellowfont));

	player[cplayer].oldscore = player[cplayer].score;

	// check to see if player got all EXTRA letters
	if ((player[cplayer].extra & 255) == 31)
	{
		if (player[cplayer].lives < 5)
		{
			player[cplayer].lives++;
         if (SOUND_ENABLED) play_sample(data[SS_ALRIGHT].dat, 255,
				(int)((pacman.x+12)/1.26), 1000, 0);
			player[cplayer].extra = 0;
		}
	}

	// Display frames per second
	if (CHEAT)
	{
      sprintf(text, "FPS %d", fps);
		textout(bmp, tinyfont, text, 135, 231, 240);
		add_to_list(&dirty, 135, 231, text_length(tinyfont, text), 6);
	}

	// display the tool active bar on the right side
	bar = FALSE;
	for (i=0; i<MAX_TOOLS; i++)
	{
      if (tool_inuse[i])
		{
			bar = TRUE;
			i = MAX_TOOLS;
		}
	}
	if (bar)
	{
		y2 = (retrace_count%tool.wait)/10;
		rectfill(bmp, 316, y2+19, 318, 170, makecol(0,255,0));
		add_to_list(&dirty, 316, y2+19, 318, 170);
		if (!(retrace_count%15))
         if (SOUND_ENABLED) play_sample(data[SS_TYPE].dat, 64, 128, 2000, 0);
	}

	// update any tiny points
	for (i=0; i<=15; i++)
	{
		if (point[i].value != 0)
		{
			if (retrace_count - point[i].counter >= point[i].delay)
			{
				point[i].moved++;
				point[i].y--;
				point[i].colour = makecol(255-point[i].moved*15,
				  255-point[i].moved*15,
				  255-point[i].moved*15);
				sprintf(text, "%d", point[i].value);
				text_mode(-1);
				textout(bmp, tinyfont, text,
				point[i].x, point[i].y, point[i].colour);
				add_to_list(&dirty, point[i].x, point[i].y,
					text_length(tinyfont, text), 6);
				if (point[i].moved == point[i].move)
				{
					point[i].value = 0;
					point[i].moved = 0;
				}
				else
				{
					point[i].counter = retrace_count;
				}
			}
			else
			{
				sprintf(text, "%d", point[i].value);
				text_mode(-1);
				textout(bmp, tinyfont, text,
				point[i].x, point[i].y, point[i].colour);
				add_to_list(&dirty, point[i].x, point[i].y,
					text_length(tinyfont, text), 6);
			}
		}
	}

	/* for dirty rectangle animation, only copy the areas that changed */
	for (i=0; i<dirty.count; i++)
	{
		add_to_list(&old_dirty, dirty.rect[i].x, dirty.rect[i].y,
			dirty.rect[i].w, dirty.rect[i].h);
	}

	/* sorting the objects really cuts down on bank switching */
	if (!gfx_driver->linear)
	{
		qsort(old_dirty.rect, old_dirty.count, sizeof(DIRTY_RECT), rect_cmp);
	}

	acquire_screen();
	if (switched_in==FALSE)
	{
		for (i=0; i<old_dirty.count; i++)
		{
			if ((old_dirty.rect[i].w == 1) && (old_dirty.rect[i].h == 1))
			{
				putpixel(screen, old_dirty.rect[i].x, old_dirty.rect[i].y, 
				getpixel(bmp, old_dirty.rect[i].x, old_dirty.rect[i].y));
			}
			else
			{
				blit(bmp, screen, old_dirty.rect[i].x, old_dirty.rect[i].y, 
					old_dirty.rect[i].x, old_dirty.rect[i].y, 
					old_dirty.rect[i].w, old_dirty.rect[i].h);
			}
		}
	}
	else
	{
		blit(bmp, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
		switched_in--;
	}
	release_screen();
}

// Load in the map/level
int loadmap_pack(char *file)
{
	PACKFILE *f;
	char testID[7];            // used for testing the id
	unsigned char testVer;     // used for testing the version

	packfile_password(pfpw);

   // open file in read mode
   f = pack_fopen(file, "r");
	if (!f)
	{
		TRACE("Failed to open %s!\n", file);
		return FALSE;
	}

	// read the id and version
	pack_fread(testID, strlen(MAP_ID)+1, f);
	pack_fread(&testVer, 1, f);

	// compare the ID and version
	if (testVer != MAP_VER || strcmp(testID, MAP_ID) != 0)
	{
		alert("Invalid map type or version.",
			NULL, NULL, "Ok", NULL, KEY_ESC, KEY_ENTER);
		pack_fclose(f);
		return FALSE;
	}

   // read the number of pills on the map
   pack_fread(&player[cplayer].pills, 1, f);

	// read map data
   pack_fread(&player[cplayer].map, sizeof(unsigned int)*315, f);
	pack_fclose(f);

	packfile_password(NULL);

	return TRUE;
}
int loadmap_disk(char *file)
{
   PACKFILE *f;
	char testID[7];            // used for testing the id
	unsigned char testVer;     // used for testing the version

   packfile_password(NULL);

	// open file in read binary mode
   f = pack_fopen(file, F_READ_PACKED);
	if (!f) return FALSE;

    // read the id and version
   pack_fread(testID, strlen(MAP_ID)+1, f);
   pack_fread(&testVer, 1, f);

	// compare the ID and version
	if (testVer != MAP_VER || strcmp(testID, MAP_ID) != 0)
	{
		alert("Invalid map type or version.",
			NULL, NULL, "Ok",NULL, KEY_ESC, KEY_ENTER);
      pack_fclose(f);
		return FALSE;
	}

	// read the number of pills & dots on the map
   pack_fread(&player[cplayer].pills, 1, f);

	// read map data
   pack_fread(&player[cplayer].map, sizeof(unsigned int)*315, f);
   pack_fclose(f);

	return TRUE;
}

void points(int points, int isapill, int isfloat)
{
	// If the present tool (tool 8) is active, add a random amount of points
	// between 1000 and 5000 if the player picked up a pill.
	if (isapill) {
      if (tool_inuse[8]) {
			points += (rand() % 4000) + 1000;
			isfloat = TRUE;
		}
		player[cplayer].pills--;
	}
	// If the x2 tool (tool 11) is active, multiply the points by 2.
   if (tool_inuse[11]) { points *= 2; isfloat = TRUE; }

	// If the x5 tool (tool 12) is active, multiply the points by 5.
   if (tool_inuse[12]) { points *= 5; isfloat = TRUE; }

	// Finally add the points to the current players score.
	player[cplayer].score += points;

	// Show small floating points on screen at current position
	if (isfloat) float_points(points, pacman.x, pacman.y);
}

// Move player
void move_players()
{
	int i, px, py, pmx, pmy,
		 tx=0, ty=0, tmx, tmy,
		 inc_x=0, inc_y=0;
	int tl;
	int x, y;
   int jump;

	// Don't update the pacman animation if he's not moving.
	// (use retrace_count for timing, it is updated 60 times per second)
	if (pacman.ox==pacman.x && pacman.oy==pacman.y) pacman.cntr=retrace_count;
	if (retrace_count - pacman.cntr >= pacman.img_delay)
	{
		pacman.cur_img += pacman.inc;
		pacman.cntr = retrace_count;
   }
	if (pacman.cur_img == 3) pacman.inc = -1;    // mouth close
	else if (pacman.cur_img == 0) pacman.inc = 1;   // mouth open

	px = pacman.x; py = pacman.y;
	pmx = pacman.mx; pmy = pacman.my;


	// Note: the map is shifted to the left 5 pixels and down 15 pixels in
	//       order to make room for the score up top and bonus fruit etc..
	//       along the right edge of the screen.
	//       Also, each tile is 15x15 pixels.
	// - To get the X position on the screen you multiply the X-map
	//   co-ordinate by 15.
	// - To get the Y position on the screen you multiply the Y-map
	//   co-ordinate by 15 and add 15.

	if (pacman.xd == 1)        // right
	{
		tx = px + 15; ty = py;
		inc_x = 1; inc_y = 0;
	}
	else if (pacman.yd == 1)   // down
	{
		tx = px; ty = py + 15;
		inc_x = 0; inc_y = 1;
	}
	else if (pacman.xd == -1)  // left
	{
		tx = px - 1; ty = py;
		inc_x = -1; inc_y = 0;
	}
	else if (pacman.yd == -1)  // up
	{
		tx = px; ty = py - 1;
		inc_x = 0; inc_y = -1;
	}

	tmx = tx/15; tmy = (ty-15)/15;
   if (player[cplayer].map[tmy][tmx] > A99LINEZZ ||
		 player[cplayer].map[tmy][tmx] < A000PPILLZZZ) {
		px+=inc_x; py+=inc_y;
		pmx = px/15; pmy = (py-15)/15;
	}

	// If the player reaches the edge,
	// teleport them to the opposite edge of the screen.
	if (px > 295) px = 5;
	else if (px < 5) px = 295;
	if (py > 215) py = 25;
	else if (py < 25) py = 215;

	// Store the old position for checking movement and update the
	// new co-ordinates.
	pacman.ox = pacman.x; pacman.x = px; pacman.mx = pmx;
	pacman.oy = pacman.y; pacman.y = py; pacman.my = pmy;

	// Check for pills and power pills under current position
	if (pmx != 10 || pmy != 11)
	{
		if (player[cplayer].map[pmy][pmx]>=A000PILL001 &&
			player[cplayer].map[pmy][pmx]<A000PPILL001)
		{
			// make sure player is centered over tile
			if (px==(pmx*15) && py==(pmy*15+15))
			{
				points(10, TRUE, FALSE);   // 10 points, it is a pill, no float.

				// erase the pill from the map
				player[cplayer].map[pmy][pmx] = A000BLANK;
				blit(data[player[cplayer].map[pmy][pmx]].dat, pacmap, 0, 0,
					pmx*15, pmy*15, 15, 15);

				// play sound sample for pill pickup
            if (SOUND_ENABLED) play_sample(data[SS_PILL].dat, 255,
					(int)((pacman.x+12)/1.26), 1000, 0);
			}
		}
      else if (player[cplayer].map[pmy][pmx]==TOOL000)
		{
			// make sure player is centered over tile
			if (px==(pmx*15) && py==(pmy*15+15))
			{
				points(1000, TRUE, TRUE);
				// erase the pill from the map
				player[cplayer].map[pmy][pmx] = A000BLANK;
				player[cplayer].tmap[pmy][pmx] = A000BLANK;
				blit(data[player[cplayer].map[pmy][pmx]].dat, pacmap, 0, 0,
					pmx*15, pmy*15, 15, 15);
            if (SOUND_ENABLED) play_sample(data[SS_DIAMOND].dat, 255,
					(int)((pacman.x+12)/1.26), 1000, 0);
			}
		}
		else if (player[cplayer].map[pmy][pmx]>=A000PPILL001 &&
			player[cplayer].map[pmy][pmx]<A000PPILLZZZ)
		{
		if (px==(pmx*15) && py==(pmy*15+15))
		{
			points(100, TRUE, FALSE);
			ghostscore=200;


			// erase the power pill from the map
			player[cplayer].map[pmy][pmx] = A000BLANK;
			blit(data[player[cplayer].map[pmy][pmx]].dat, pacmap, 0, 0,
				pmx*15, pmy*15, 15, 15);
         if (SOUND_ENABLED) play_sample(data[SS_PPILL].dat, 255,
				(int)((pacman.x+12)/1.26), 1000, 0);

			for (i=0; i<=3; i++)
			{
				if (ghost[i].dead == FALSE)
				{
					ghost[i].scared = TRUE;
					ghost[i].cur_img = 4;
					ghost[i].stimer = 0;
               if (SOUND_ENABLED) {
                  if (voice_check(back1)!=NULL)
                  {
                     stop_sample(data[SS_BACKGROUND1].dat);
                     back1 = -1;
                  }
                  if (voice_check(back2)==NULL)
                     back2 = play_sample(data[SS_BACKGROUND2].dat,
                                         255, 128, 1000, 1);
                  }
               }
            }
			}
		}
	}

	// Check for pickups
	else if ((player[cplayer].map[pmy][pmx] >= PU_APPLE) &&
				(player[cplayer].map[pmy][pmx] < PU_ZZZ))
	{
		// make sure player is centered over tile
		if (px==(pmx*15) && py==(pmy*15+15))
		{
			points(player[cplayer].pvalue, FALSE, TRUE);
			pickup.active = FALSE;
			// erase the pickup from the map
			player[cplayer].map[pmy][pmx] = A000BLANK;
			blit(data[A000BLANK].dat, pacmap, 0, 0, pmx*15, pmy*15, 15, 15);
         if (SOUND_ENABLED) play_sample(data[SS_GULP].dat, 255,
				(int)((pacman.x+12)/1.26), 1000, 0);
		}
	}

	// Check for tools
   else if ((player[cplayer].map[pmy][pmx] >= TOOL000) &&
            (player[cplayer].map[pmy][pmx] < TOOLZZZ))
	{
		// make sure player is centered over tile
		if (px==(pmx*15) && py==(pmy*15+15))
		{
         tl = player[cplayer].map[pmy][pmx] - TOOL000;

			do {
            tool_inuse[9] = FALSE;
				tool.active = FALSE;
				switch (tl)
				{
               case (0): { // DIAMOND / TOOL000
						for (y=0; y<15; y++)
						{
							for (x=0; x<21; x++)
							{
                        tool_inuse[0] = TRUE;
								player[cplayer].tmap[y][x] = player[cplayer].map[y][x];
								if (player[cplayer].map[y][x] >= A000PILL001 &&
									player[cplayer].map[y][x] < A000PPILL001)
								{
                           player[cplayer].map[y][x] = TOOL000;
                           spr = data[TOOL000].dat;
									draw_sprite(pacmap, spr,
													x*15+7-(spr->w>>1), y*15+7-(spr->h>>1));
									acquire_screen();
									draw_sprite(screen, spr,
													x*15+7-(spr->w>>1), y*15+22-(spr->h>>1));
									release_screen();
								}
							}
						}
						break; }
               case (1): { // EXTRA A / TOOL001
						player[cplayer].extra |= 1;
						break; }
               case (2): { // EXTRA E / TOOL002
						player[cplayer].extra |= 2;
						break; }
               case (3): { // EXTRA R / TOOL003
						player[cplayer].extra |= 4;
						break; }
               case (4): { // EXTRA T / TOOL004
						player[cplayer].extra |= 8;
						break; }
               case (5): { // EXTRA X / TOOL005
						player[cplayer].extra |= 16;
						break; }
               case (6): { // FREEZE / TOOL006
                  tool_inuse[6] = TRUE;
						// Freeze all ghosts that aren't "dead".
						for (i=0; i<4; i++) if (!ghost[i].dead) ghost[i].frozen = TRUE;
						break; }
               case (7): { // JUMP / TOOL007
                  tool_inuse[7] = TRUE;
                  jump = player[cplayer].level;
                  while (jump==player[cplayer].level)
                     jump = rand() % (LEVELZZZ-LEVEL001);
                  player[cplayer].level = jump;
                  if (player[cplayer].wrap) player[cplayer].pvalue = 10000;
                  else player[cplayer].pvalue = 500 * jump;
                  points(player[cplayer].pills*10, FALSE, FALSE);
                  if (player[cplayer].pvalue > 10000)
                     player[cplayer].pvalue = 10000;
                  player[cplayer].pills=0;
                  SKIPLEVEL = TRUE;
						break; }
               case (8): { // PRESENT / TOOL008
                  tool_inuse[8] = TRUE;
						break; }
               case (9): { // QUESTION / TOOL009
                  tool_inuse[9] = TRUE;
                  while (tl==9) tl = rand() % MAX_TOOLS;
						tool.current = tl;
						break; }
               case (10): { // SHIELD / TOOL010
                  tool_inuse[10] = TRUE;
						break; }
               case (11): { // X2 / TOOL011
                  tool_inuse[11] = TRUE;
						break; }
               case (12): { // X5 / TOOL012
                  tool_inuse[12] = TRUE;
						break; }
               case (13): { // SKULL / TOOL013 (unlucky number eh? :))
						pacman.dead = TRUE;
						break; }
               case (14): { // DYNAMITE / TOOL014
                  if (SOUND_ENABLED) play_sample(data[SS_BOOM].dat, 255, 128, 1000, 0);
                  for (i=0; i<4; i++)
                     if (ghost[i].scared && !ghost[i].dead) {
                        ghost[i].dead=TRUE;
                        ghost[i].scared=FALSE;
                        points(5000, FALSE, FALSE);
                        float_points(5000, ghost[i].x, ghost[i].y);
                     }
                  break; }
				}
         } while (tool_inuse[9]);
			// erase the tool from the map
			player[cplayer].map[11][10] = A000BLANK;
			blit(data[A000BLANK].dat, pacmap, 0, 0, pmx*15, pmy*15, 15, 15);
			update_screen();
         if (SOUND_ENABLED) play_sample(data[SS_PPILL].dat, 255,
							(int)((pacman.x+12)/1.26), 1000, 0);
		}
	}
}

// Level cleared! (Win routine)
void Win() {
	int s, x, y, sw, sh;

   if (SOUND_ENABLED) {
      if (voice_check(back1)!=NULL)
      {
         stop_sample(data[SS_BACKGROUND1].dat);
         back1 = -1;
      }
      if (voice_check(back2)!=NULL)
      {
         stop_sample(data[SS_BACKGROUND2].dat);
         back2 = -1;
      }
   }

   acquire_screen();

	blit(pacmap, screen, 0, 0, 0, 15, pacmap->w, pacmap->h);

	if (!SKIPLEVEL) {
		for (x=0; x<=3; x++)
		{
         blit(pacmap, screen, 0, 0, 0, 15, pacmap->w, pacmap->h);
         if (SOUND_ENABLED) {
            stop_sample(data[SS_ENDOFLEVEL].dat);
            play_sample(data[SS_ENDOFLEVEL].dat, 255, 128, 1000, 0);
         }
      	rest(250);
         rectfill(screen, 0, 15, pacmap->w, pacmap->h+15, 0);
			rest(250);
		}
      blit(pacmap, screen, 0, 0, 0, 15, pacmap->w, pacmap->h);
	}

	SKIPLEVEL = FALSE;
	sw = SCREEN_W>>1;
	sh = SCREEN_H>>1;
	x = rand()%sw;
	y = rand()%sh+15;
	clear(bmp);
	blit(screen, bmp, x, y, 0, 0, sw, sh);
   if (SOUND_ENABLED) play_sample(data[SS_ENDOFLEVEL2].dat, 255, 128, 1000, 0);
   for (s=0; s<=96; s+=32)
	{
		stretch_blit(bmp, screen,  0, 0, sw-s, sh-s,
						 0, 15, SCREEN_W, SCREEN_H-15);
		rest(250);
	}
   release_screen();
}

// Player died
void Dead() {
	int i;
	BITMAP *g = data[GAMEOVER].dat;

   if (SOUND_ENABLED) {
      if (voice_check(back1)!=NULL)
      {
         stop_sample(data[SS_BACKGROUND1].dat);
         back1 = -1;
      }
      if (voice_check(back2)!=NULL)
      {
         stop_sample(data[SS_BACKGROUND2].dat);
         back2 = -1;
      }
   }

	pickup.active = FALSE;

	reset_active_tools();

   if (SOUND_ENABLED) play_sample(data[SS_PACDEAD].dat, 255,
		(int)((pacman.x+12)/1.26), 1000, 0);
	for (i=4; i<20; i++)
	{
		pacman.cur_img = i;
		update_screen();
		rest(80);
	}
	player[cplayer].lives--;
	if (player[cplayer].lives < 0) {
		player[cplayer].lives = 0;
		player[cplayer].extra = 0;
	}
	pacman.cur_img = 1;
	pacman.x = 150; pacman.y = 180;
	pacman.xd = 1; pacman.yd = 0;
	blit(pacmap, screen, 0, 0, 0, 15, pacmap->w, pacmap->h);
	if (player[cplayer].lives == 0)
	{
		acquire_screen();
		masked_blit(g, screen, 0, 0,
			(SCREEN_W>>1)-(g->w>>1), (SCREEN_H>>1)-(g->h>>1), g->w, g->h);
		release_screen();
	}
	rest(2000);
}

// Title screen
void title()
{
	int choice = -1;

	gui_bg_color = makecol(0,0,255);
	gui_fg_color = makecol(255,255,0);

	exit_game = FALSE;
	done = FALSE;
	game_over = FALSE;

   set_pallete(data[PAL_DEFAULT].dat);

	clear(bmp);
   blit(data[MENU_BACKGROUND].dat, bmp, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
   draw_sprite(bmp, data[TITLE].dat, 0, 0);
   text_mode(-1);
	textout_centre(bmp, font, "by Neil Roy", 160, 164, -1);
	textout_centre(bmp, font, "(for Wanda)", 160, 180, -1);
   textout_centre(bmp, tinyfont, VERSION, 160, SCREEN_H-6, makecol(255,0,0));
   acquire_screen();
	blit(bmp, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
   release_screen();
   if (MUSIC_ENABLED) play_mod(data[MOD_MAIN].dat, TRUE);

	clear_keybuf();
   while(!keypressed() && !JB1) input_joycheck();
	clear_keybuf();

	do {
		set_mouse_range(mouse_x, mouse_y, mouse_x, mouse_y);
		choice = main_menu();
		difficulty = dl;
		players = pl+1;
	} while(choice!=0 && choice!=1 && choice != 6);

	if (choice==6)
	{
		exit_game = done = game_over = TRUE;
		player[cplayer].lives = 0;
	}

   if (MUSIC_ENABLED) stop_mod();
	acquire_screen();
	clear(screen);
	release_screen();
	clear(bmp);
}

// move a ghost in a direction
void move_dir(int d, int i)
{
	// d = direction ghost is currently moving in (0-3), i = ghost 0-3.
	int a1=0, a2=0;      // alternate directions to check
	int d1;              // opposite direction of d
	int rand_dir = 0;    // pick random direction or chase pacman?
	int r;               // random direction variable

	if (d==RIGHT) { a1=DOWN; a2=UP; }
	if (d==LEFT) { a1=UP; a2=DOWN; }
	if (d==DOWN) { a1=RIGHT; a2=LEFT; }
	if (d==UP) { a1=LEFT; a2=RIGHT; }

	if (d>1) d1=d-2;
	else d1=d+2;

	rand_dir = rand()%((i+1)*2);

	switch(difficulty)
	{
      case(0):{ speed = 1.4; break; }
		case(1):{ speed = 1; break; }
      case(2):{ speed = .6; break; }
	}
	if (ghost[i].dead || ghost[i].scared) rand_dir = 1;

	// is ghost in home base?
	if (ghost[i].mx==10 && ghost[i].my==9 && ghost[i].dead==TRUE)
	{
		ghost[i].scared = FALSE;
		ghost[i].inc = 1;
		ghost[i].cur_img = 0;
		ghost[i].dead = FALSE;
	}

	// no other direction to move in so reverse direction
	else if (dir[a1].b && dir[a2].b && dir[d].b)
	{
		ghost[i].xd = dir[d1].x;
		ghost[i].yd = dir[d1].y;
	}

	// enter home base to be healed?
	else if (ghost[i].mx==10 && ghost[i].my==7 && ghost[i].dead==TRUE)
	{
		ghost[i].xd = 0;
		ghost[i].yd = 1;
	}

	// Chase pacman if not scared?
	else if (!rand_dir)
	{
		if (pacman.my > ghost[i].my)
		{
			if (a1 == DOWN && !dir[a1].b)
			{
				ghost[i].xd = dir[a1].x;
				ghost[i].yd = dir[a1].y;
			}
			else if (a2 == DOWN && !dir[a2].b)
			{
				ghost[i].xd = dir[a2].x;
				ghost[i].yd = dir[a2].y;
			}
			else if (d == DOWN && !dir[d].b)
			{
				ghost[i].xd = dir[d].x;
				ghost[i].yd = dir[d].y;
			}
			else if (pacman.mx > ghost[i].mx)
			{
				if (a1 == RIGHT && !dir[a1].b)
				{
					ghost[i].xd = dir[a1].x;
					ghost[i].yd = dir[a1].y;
				}
				else if (a2 == RIGHT && !dir[a2].b)
				{
					ghost[i].xd = dir[a2].x;
					ghost[i].yd = dir[a2].y;
				}
				else
				{
					rand_dir = TRUE;
				}
			}
			else if (pacman.mx < ghost[i].mx)
			{
				if (a1 == LEFT && !dir[a1].b)
				{
					ghost[i].xd = dir[a1].x;
					ghost[i].yd = dir[a1].y;
				}
				else if (a2 == LEFT && !dir[a2].b)
				{
					ghost[i].xd = dir[a2].x;
					ghost[i].yd = dir[a2].y;
				}
				else
				{
					rand_dir = TRUE;
				}
			}
			else
			{
				rand_dir = TRUE;
			}
		}
		else if (pacman.my < ghost[i].my)
		{
			if (a1 == UP && !dir[a1].b)
			{
				ghost[i].xd = dir[a1].x;
				ghost[i].yd = dir[a1].y;
			}
			else if (a2 == UP && !dir[a2].b)
			{
				ghost[i].xd = dir[a2].x;
				ghost[i].yd = dir[a2].y;
			}
			else if (d == UP && !dir[d].b)
			{
				ghost[i].xd = dir[d].x;
				ghost[i].yd = dir[d].y;
			}
			else if (pacman.mx > ghost[i].mx)
			{
				if (a1 == RIGHT && !dir[a1].b)
				{
					ghost[i].xd = dir[a1].x;
					ghost[i].yd = dir[a1].y;
				}
				else if (a2 == RIGHT && !dir[a2].b)
				{
					ghost[i].xd = dir[a2].x;
					ghost[i].yd = dir[a2].y;
				}
				else
				{
					rand_dir = TRUE;
				}
			}
			else if (pacman.mx < ghost[i].mx)
			{
				if (a1 == LEFT && !dir[a1].b)
				{
					ghost[i].xd = dir[a1].x;
					ghost[i].yd = dir[a1].y;
				}
				else if (a2 == LEFT && !dir[a2].b)
				{
					ghost[i].xd = dir[a2].x;
					ghost[i].yd = dir[a2].y;
				}
				else
				{
					rand_dir = TRUE;
				}
			}
			else
			{
				rand_dir = TRUE;
			}
		}
		else if (pacman.mx < ghost[i].mx)
		{
			if (a1 == LEFT && !dir[a1].b)
			{
				ghost[i].xd = dir[a1].x;
				ghost[i].yd = dir[a1].y;
			}
			else if (a2 == LEFT && !dir[a2].b)
			{
				ghost[i].xd = dir[a2].x;
				ghost[i].yd = dir[a2].y;
			}
			else if (d == LEFT && !dir[d].b)
			{
				ghost[i].xd = dir[d].x;
				ghost[i].yd = dir[d].y;
			}
			else
			{
				rand_dir = TRUE;
			}
		}
		else if (pacman.mx > ghost[i].mx)
		{
			if (a1 == RIGHT && !dir[a1].b)
			{
				ghost[i].xd = dir[a1].x;
				ghost[i].yd = dir[a1].y;
			}
			else if (a2 == RIGHT && !dir[a2].b)
			{
				ghost[i].xd = dir[a2].x;
				ghost[i].yd = dir[a2].y;
			}
			else if (d == RIGHT && !dir[d].b)
			{
				ghost[i].xd = dir[d].x;
				ghost[i].yd = dir[d].y;
			}
			else
			{
				rand_dir = TRUE;
			}
		}
		else
		{
			rand_dir = TRUE;
		}
	}

	// choose random direction
	if (rand_dir)
	{
		if (!dir[d].b) { r = rand()%3; }
		else { r = rand()%2 + 1; }
		if (r==1)
		{
			if (!dir[a1].b)
			{
				ghost[i].xd = dir[a1].x;
				ghost[i].yd = dir[a1].y;
			}
			else if (!dir[a2].b)
			{
				ghost[i].xd = dir[a2].x;
				ghost[i].yd = dir[a2].y;
			}
		}
		else if (r==2)
		{
			if (!dir[a2].b)
			{
				ghost[i].xd = dir[a2].x;
				ghost[i].yd = dir[a2].y;
			}
			else if (!dir[a1].b)
			{
				ghost[i].xd = dir[a1].x;
				ghost[i].yd = dir[a1].y;
			}
		}
		else if (r==0)
		{
			if (dir[a1].b && dir[a2].b && dir[d].b)
			{
				ghost[i].xd = dir[d1].x;
				ghost[i].yd = dir[d1].y;
			}
		}
	}
}


// Check which direction ghosts should move in
void move_ghosts()
{
	int i;

	for (i=0; i<=3; i++)
	{
		// Calculate ghost's map position
		ghost[i].mx = (int)(ghost[i].x)/15;
		ghost[i].my = (int)(ghost[i].y-15)/15;

		// Update ghost animation
		if (retrace_count - ghost[i].cntr >= ghost[i].img_delay)
		{
			ghost[i].cur_img += ghost[i].inc;
			if (ghost[i].cur_img==4 && ghost[i].scared==FALSE)
				ghost[i].cur_img=0;
			ghost[i].cntr = retrace_count;
		}

		if (ghost[i].scared == TRUE)
		{
			// If ghost is scared and the image isn't blue...
			if (ghost[i].cur_img < 4)
			{
				ghost[i].cur_img = 4;   // turn it blue
				ghost[i].stimer = 0;    // start the scared timer
			}

			// cycle the scared animation back and forth
			if (ghost[i].cur_img == 7) ghost[i].inc = -1;
			else if (ghost[i].cur_img == 4) ghost[i].inc = 1;

			// increment the scared timer
			if (retrace_count - ghost[i].scntr >= 4)
			{
				ghost[i].stimer++;
				ghost[i].scntr = retrace_count;
			}

			// If the timer runs out, reset the ghost to normal
			if (ghost[i].stimer > ghost[i].stime)
			{
				ghost[i].scared = FALSE;
				ghost[i].inc = 1;
				ghost[i].cur_img = 0;
            if (SOUND_ENABLED) {
               if (voice_check(back2)!=NULL)
               {
                  stop_sample(data[SS_BACKGROUND2].dat);
                  back2 = -1;
               }
               if (voice_check(back1)==NULL) 
               back1 = play_sample(data[SS_BACKGROUND1].dat, 255, 128, 1000, 1);
            }
			}
		}

		// Check for intersection
		if (ghost[i].x%15 == 0 && (ghost[i].y-15)%15 == 0)
		{
			// check for boundries and place good directions in variable
			dir[RIGHT].b = TRUE;
         if (player[cplayer].map[ghost[i].my][ghost[i].mx+1] > A99LINEZZ ||
				player[cplayer].map[ghost[i].my][ghost[i].mx+1] < A000PPILLZZZ)
				dir[RIGHT].b = FALSE;
			dir[LEFT].b = TRUE;
         if (player[cplayer].map[ghost[i].my][ghost[i].mx-1] > A99LINEZZ ||
				player[cplayer].map[ghost[i].my][ghost[i].mx-1] < A000PPILLZZZ)
				dir[LEFT].b = FALSE;
			dir[DOWN].b = TRUE;
			if (!(ghost[i].mx==10 && ghost[i].my==7 && ghost[i].dead==FALSE))
            if (player[cplayer].map[ghost[i].my+1][ghost[i].mx] > A99LINEZZ
					|| player[cplayer].map[ghost[i].my+1][ghost[i].mx]
					< A000PPILLZZZ)
					dir[DOWN].b = FALSE;
			dir[UP].b = TRUE;
         if (player[cplayer].map[ghost[i].my-1][ghost[i].mx] > A99LINEZZ ||
				player[cplayer].map[ghost[i].my-1][ghost[i].mx] < A000PPILLZZZ)
				dir[UP].b = FALSE;

			if (ghost[i].xd == 1) move_dir(RIGHT, i);
			else if (ghost[i].yd == 1) move_dir(DOWN, i);
			else if (ghost[i].xd == -1) move_dir(LEFT, i);
			else if (ghost[i].yd == -1) move_dir(UP, i);
		}

      if (!tool_inuse[6] || !ghost[i].frozen) {
			ghost[i].ox = ghost[i].x;
			ghost[i].oy = ghost[i].y;
			ghost[i].x += ghost[i].xd;
			ghost[i].y += ghost[i].yd;
		}

		// If the ghost reaches the right or left edge, teleport them to the
		// opposite edge of the screen.  Block upper and lower limits.
		if (ghost[i].x > 299) ghost[i].x = 1; // 5
		else if (ghost[i].x < 1) ghost[i].x = 299; // 295
		if (ghost[i].y > 224) ghost[i].y = 16; // 25
		else if (ghost[i].y < 16) ghost[i].y = 224; // 215
	}
}

// Checks to see if pacman and ghost collide
void check_collision()
{
	int i, r, minx, maxx, miny, maxy;

	minx = pacman.x-15; maxx = pacman.x+15;
	miny = pacman.y-15; maxy = pacman.y+15;

	for (i=0; i<=3; i++)
	{
		// Check to see if pacman and ghost collided
		if ((ghost[i].x > minx && ghost[i].x < maxx) &&
			(ghost[i].y > miny && ghost[i].y < maxy))
		{
			// Pacman and ghost collided, is the ghost edible? ;-)
			if (ghost[i].scared == TRUE && ghost[i].dead == FALSE)
			{
				ghost[i].dead = TRUE;
				ghost[i].frozen = FALSE;
				points(ghostscore, FALSE, TRUE);
				ghostscore <<= 1;
				r = rand()%3;
            if (SOUND_ENABLED) play_sample(data[SS_GHOSTDIE1+r].dat, 255,
								(int)((pacman.x+12)/1.26), 1000, 0);
			}
         else if (!ghost[i].dead && !GODMODE && !tool_inuse[10])
			{
				pacman.dead = TRUE;
				player[cplayer].dead = TRUE;
			}
		}
	}
}

// MAIN
int main(int argc, char *argv[])
{
	int i;
	char levelname[13];
	BITMAP *temp=NULL;

	// Make certain we know the exact path to get pacman.dat from
	strcpy(path, argv[0]);
	strcpy(text, path);
   strcpy(get_filename(text), "DPacman.dat");

	// Handle command line options here
	CHEAT = FALSE;
	if (argc >= 2)
	{
		for (i=1; i<argc; i++)
		{
			if (!strcmp(argv[i], "-?") || !strcmp(argv[i], "/?"))
			{
				printf("\n%s [option]\n\n", get_filename(argv[0]));
				printf("     -wanda     enables cheat mode\n");
				printf("     -version   shows current version\n");
				return 0;
			}
			if (!strcmp(argv[i], "-wanda")) CHEAT = TRUE;
			if (!strcmp(argv[i], "-version"))
			{
				printf("\n%s version %s\n", NAME, VERSION);
				return 0;
			}
		}
	}

	init();

   temp=create_bitmap(169, 50);
	if (temp==NULL)
		error("Error creating temp bitmap.\n (%s)\n", allegro_error);

	// set up the interrupt routines...
	install_int(fps_proc, 1000);

	if (use_retrace_proc)
		retrace_proc = game_timer;
	else
		install_int(game_timer, 10);

	while (!exit_game)
	{
		hiscore = get_hiscore();

		for (i=0; i<=1; i++) {
			player[i].level = 1;
			player[i].oldlevel = 0;
			player[i].pvalue = 500;
			player[i].score = 0;
			player[i].oldscore = 0;
			player[i].extra = 0;
         player[i].wrap = 0;
		}

		// Only set single player lives,
		// second player gets his lives if a two player
		// game is selected.
		player[0].lives = 3;

		cplayer = 0;
		pacman.dead = FALSE;

		title();
		if (exit_game) EndGame();
		if (players == 2) player[1].lives = 3;

		while (game_over==FALSE)
		{
			if (pacman.dead && (player[1-cplayer].lives>0))
				cplayer = 1 - cplayer;

			if (player[cplayer].level != player[cplayer].oldlevel)
			{
            sprintf(levelname,"level%03d.map", player[cplayer].level);
            if (!loadmap_disk(levelname))
				{
               sprintf(levelname,"dpacman.dat#level%03d", player[cplayer].level);
					if (!loadmap_pack(levelname))
					{
						// *** Insert Completed all levels congrats screen ***
                  if (SOUND_ENABLED) play_sample(data[SS_APPLAUSE].dat, 255, 128, 1000, 0);
                  player[cplayer].wrap++;
                  if (speed > .6) speed -= .1;
						player[cplayer].level = 1;
                  if (!loadmap_disk("level001.map"))
                     if (!loadmap_pack("dpacman.dat#level001"))
							{
                        allegro_message("Error: level001 not found!\n");
								exit(1);
							}
					}
				}
				player[cplayer].oldlevel = player[cplayer].level;
			}
			init_variables();
         reset_active_tools();
			update_screen();
         if (cplayer == 0)
			{
				sprintf(text, "GET READY PLAYER ONE");
			}
			else
			{
				sprintf(text, "GET READY PLAYER TWO");
			}
			clear_to_color(temp, makecol(0,0,0));
         rect(temp, 0, 0, 168, 49, makecol(0,0,255));
			text_mode(-1);
			textprintf_centre(temp, redfont,temp->w>>1,
									(temp->h>>1)-(text_height(redfont)*1.5), -1,
									 "LEVEL %d", player[cplayer].level);
			textout_centre(temp, font, text, temp->w>>1,
								(temp->h>>1)-(text_height(font)>>1), -1);
			textout_centre(temp, font, "PRESS ANY KEY", temp->w>>1,
								(temp->h>>1)+(text_height(font)>>1), -1);
			acquire_screen();
         blit(temp, screen, 0, 0, (SCREEN_W>>1)-(temp->w>>1)-3,
              (SCREEN_H>>1)-(temp->h>>1), temp->w, temp->h);
			i = Continue();
			blit(pacmap, screen, 0, 0, 0, 15, map_width, map_height);
			release_screen();
			if (i==3)
			{
				done=TRUE;
				game_over=TRUE;
				player[cplayer].lives=0;
				player[cplayer].dead=TRUE;
				pacman.dead=TRUE;
				player[cplayer].extra = 0;
			}
         if (voice_check(back1)==NULL && SOUND_ENABLED) 
				back1 = play_sample(data[SS_BACKGROUND1].dat, 255, 128, 1000, 1);
			game_time = 0;
			while (done==FALSE && pacman.dead==FALSE)
			{
				poll_keyboard();
				poll_joystick();
				while (game_time > 0)
				{
					poll_keyboard();
               input_check();
					move_players();
					move_ghosts();
					check_collision();
					game_time-=speed;
				}
				update_screen();
				frame_count++;
				if (player[cplayer].pills==0)
				{
					Win();
					done=TRUE;
				}
				if (pacman.dead==TRUE)
				{
					Dead();
					player[cplayer].dead = TRUE;
					done = TRUE;
				}
			}
			if (player[0].lives==0 && player[1].lives==0) game_over=TRUE;
			if (player[cplayer].pills==0)
			{
				player[cplayer].level++;
            pickup.active = FALSE; tool.active = FALSE;

				// Give player 1000 points for completing the level
				player[cplayer].score+=1000;

				// Limit points for pickups to a maximum of 10000
				if (player[cplayer].pvalue < 10000) player[cplayer].pvalue+=500;
         }
		}

      if (SOUND_ENABLED) {
         if (voice_check(back1)!=NULL)
         {
            stop_sample(data[SS_BACKGROUND1].dat);
            back1 = -1;
         }
         if (voice_check(back2)!=NULL)
         {
            stop_sample(data[SS_BACKGROUND2].dat);
            back2 = -1;
         }
      }

      if (!CHEAT)
		{
			// Only add the score(s) to hiscore table if cheating is disabled
			score_table(player[0].score, 1);
			if (players==2) score_table(player[1].score, 2);
		}
		else
		{
			score_table(0, 0);
		}
	}

	EndGame();
	destroy_bitmap(temp);
	return 0;
} END_OF_MAIN();
