#ifndef nr__global__h
#define nr__global__h

extern const int screen_width, screen_height, screen_depth;
extern const int map_width, map_height;
extern DATAFILE *data;

#endif
