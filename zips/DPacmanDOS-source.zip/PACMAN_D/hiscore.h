#ifndef NR__HISCORE__
#define NR__HISCORE__

/* from hiscore.c */
void init_hiscore();
void shutdown_hiscore();
void score_table(unsigned int score, int player);
int get_hiscore();

#endif   /* NR__HISCORE__ */
