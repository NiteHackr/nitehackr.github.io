#ifndef nr_input_h
#define nr_input_h

void input_init();
int Continue();
void input_joycheck();
void input_check();

extern int CHEAT, GODMODE, SKIPLEVEL, DIAMONDS,
           EXTRA_E, EXTRA_X, EXTRA_T, EXTRA_R, EXTRA_A;

extern int JB1, JB2, JSU, JSD, JSR, JSL;

#endif
