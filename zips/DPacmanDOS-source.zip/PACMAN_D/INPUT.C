#include "allegro.h"
#include "pacman.h"
#include "pacdat.h"
#include "error.h"
#include "input.h"
#include "menu.h"

int CHEAT = FALSE;
int GODMODE = FALSE;
int SKIPLEVEL = FALSE;
int DIAMONDS = FALSE;
int EXTRA_E = FALSE;
int EXTRA_X = FALSE;
int EXTRA_T = FALSE;
int EXTRA_R = FALSE;
int EXTRA_A = FALSE;

int JB1, JB2, JSU, JSD, JSR, JSL;

void input_init()
{
	if (install_keyboard()<0)
		error("Error initializing keyboard.", allegro_error);
	install_mouse();
   install_joystick(JOY_TYPE_AUTODETECT);
}

// Continue function (waits for input before continuing)
int Continue()
{
   int exit = 0;

   clear_keybuf();

   if (INPUT_MODE==JOYSTICK) {
      while(joy_b1) {
         poll_joystick();
         if (key[KEY_ESC]) break;
      }
      while(joy_b2) {
         poll_joystick();
         if (key[KEY_ESC]) break;
      }
   }

	do
	{
      if (keypressed())
		{
         if (key[KEY_F12]) {
            save_screen();
            exit = 1;
         }
         else if (key[KEY_ESC]) exit = 3;
         else exit = 1;
		}

      if (INPUT_MODE==JOYSTICK) {
         poll_joystick();
         if (joy_b1) exit = 1;
         if (joy_b2) exit = 3;
      }
      if (mouse_b & 1) exit=2;
   } while(exit==0);

	return exit;
}

void input_joycheck()
{
   poll_joystick();
   if (joy_b1)                   // button 1/A = key enter
      JB1 = TRUE;
   else if (joy_b2)              // button 2/B = key escape
      JB2 = TRUE;

   if (joy[0].stick[0].axis[0].d1)           // left = key left
      JSL = TRUE;
   else if (joy[0].stick[0].axis[0].d2)      // right = key right
      JSR = TRUE;
   else if (joy[0].stick[0].axis[1].d1)      // up = key up
      JSU = TRUE;
   else if (joy[0].stick[0].axis[1].d2)      // down = key down
      JSD = TRUE;
}

// Check for input
void input_check()
{
   if (key[KEY_F12]) save_screen();
   if (key[KEY_P]) // pause
   {
      clear_keybuf();
      acquire_screen();
      textout_centre(screen, redfont, "GAME PAUSED",
         SCREEN_W>>1, SCREEN_H>>1, -1);
      release_screen();
      while(!keypressed());
      blit(bmp, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
      game_time = 0;
   }

   // *** PROGRAMMER'S KEYS ***
   if (CHEAT)
   {
      if (key[KEY_F9] && !GODMODE)    // enable "God mode"
      {
          GODMODE = TRUE;
         play_sample(data[SS_HEAVEN].dat, 255, 128, 1000, 0);
      }
      if (key[KEY_F10] && GODMODE)    // disable "God mode"
      {
         GODMODE = FALSE;
         play_sample(data[SS_GULP].dat, 255, 128, 1000, 0);
      }
      if (key[KEY_F11] && (player[cplayer].lives<5)) player[cplayer].lives=5;
      if (key[KEY_PGUP])              // end level
      {
         player[cplayer].pills=0;
         SKIPLEVEL = TRUE;
      }
      if (key[KEY_D] && !DIAMONDS) DIAMONDS = TRUE;
      if (key[KEY_1] && !EXTRA_E) EXTRA_E = TRUE;
      if (key[KEY_2] && !EXTRA_X) EXTRA_X = TRUE;
      if (key[KEY_3] && !EXTRA_T) EXTRA_T = TRUE;
      if (key[KEY_4] && !EXTRA_R) EXTRA_R = TRUE;
      if (key[KEY_5] && !EXTRA_A) EXTRA_A = TRUE;
   }

   JB1 = FALSE, JB2 = FALSE;
   JSU = FALSE, JSD = FALSE, JSR = FALSE, JSL = FALSE;
   if (INPUT_MODE==JOYSTICK) input_joycheck();
   // Only allow a change in direction if the player is reversing direction
   // or they are perfectly centered over a tile, then check for lines
   // blocking the path.
   if (key[KEY_ESC] || JB2)
   {
      done = TRUE; game_over = TRUE;
      if (voice_check(back1)!=NULL)    // Stop sound if it is playing
      {
         stop_sample(data[SS_BACKGROUND1].dat);
         back1 = -1;
      }
      if (voice_check(back2)!=NULL)
      {
         stop_sample(data[SS_BACKGROUND2].dat);
         back2 = -1;
      }
      player[cplayer].lives=0;
      player[cplayer].level=1;
   }

   if (key[KEY_RIGHT] || JSR)
   {
      if ((pacman.x==(pacman.mx*15) && pacman.y==(pacman.my*15+15))
         || pacman.xd==-1)
      {
         if (player[cplayer].map[pacman.my][pacman.mx+1] > A99LINEZZ
            || player[cplayer].map[pacman.my][pacman.mx+1] < A000PPILLZZZ)
         {
            pacman.xd = 1;
            pacman.yd = 0;
         }
      }
   }

   if (key[KEY_DOWN] || JSD)
   {
      if (!(pacman.mx==10 && pacman.my==7))
      {
         if ((pacman.x==(pacman.mx*15) && pacman.y==(pacman.my*15+15))
            || pacman.yd==-1)
         {
            if (player[cplayer].map[pacman.my+1][pacman.mx] > A99LINEZZ ||
                player[cplayer].map[pacman.my+1][pacman.mx] < A000PPILLZZZ)
            {
               pacman.yd = 1;
               pacman.xd = 0;
            }
         }
      }
   }

   if (key[KEY_LEFT] || JSL)
   {
      if ((pacman.x==(pacman.mx*15) && pacman.y==(pacman.my*15+15))
         || pacman.xd==1)
      {
         if (player[cplayer].map[pacman.my][pacman.mx-1] > A99LINEZZ ||
            player[cplayer].map[pacman.my][pacman.mx-1] < A000PPILLZZZ)
         {
            pacman.xd = -1;
            pacman.yd = 0;
         }
      }     
   }

   if (key[KEY_UP] || JSU)
   {
      if ((pacman.x==(pacman.mx*15) && pacman.y==(pacman.my*15+15))
         || pacman.yd==1)
      {
         if (player[cplayer].map[pacman.my-1][pacman.mx] > A99LINEZZ ||
            player[cplayer].map[pacman.my-1][pacman.mx] < A000PPILLZZZ)
         {
            pacman.yd = -1;
            pacman.xd = 0;
         }
      }
   }
}
