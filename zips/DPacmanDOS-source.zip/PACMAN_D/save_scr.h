#ifndef NR__SAVE_SCR__
#define NR__SAVE_SCR__

/* from save_scr.c */
void save_screen();

#endif   /* NR__SAVE_SCR__ */
