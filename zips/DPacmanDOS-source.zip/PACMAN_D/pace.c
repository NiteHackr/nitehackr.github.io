#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>       // the randomize function requires this
#include "allegro.h"
#include "pacdat.h"
#include "save_scr.h"

const char* MAP_ID = "pacmap";   // ID of the map
const unsigned char MAP_VER = 5; // version of the map

DATAFILE *data;
BITMAP *buf1=NULL, *buf2=NULL, *bmp=NULL;
BITMAP *sprite=NULL;

char path[256], text[256];
unsigned int map[15][21];
int grid=TRUE;

int piece_index = A00LINE01;
int piece = A00LINE01;
int setsprite=FALSE;
int spritex=0, spritey=0;

char mapName[256];
unsigned short pills = 0;
unsigned char saved = TRUE;

// packfile password (subtract 17 from each ascii value)
char pfpw[] = "EHDFAGDGI";

/****************************************************************************/
void init(void)
{
	int i;

	allegro_init();
	install_keyboard();
	install_timer();
	install_mouse();
	install_sound(DIGI_AUTODETECT, MIDI_AUTODETECT, NULL);

	set_gfx_mode(GFX_AUTODETECT, 640, 480, 0, 0);

	for (i=0; i<9; i++) { pfpw[i]-=17; }   //decode password

	packfile_password(pfpw);
	data = load_datafile(text);
	if (!data)
	{
		allegro_exit();
		printf("Error loading %s!\n\n", text);
		exit(1);
	}
	packfile_password(NULL);

	set_pallete(black_pallete);
	buf1=create_bitmap(640,480);
	buf2=create_bitmap(640,480);
	clear(screen);
	clear(buf1);
	clear(buf2);
	srand((unsigned)time(NULL));  // seed the random number generator
}
/****************************************************************************/
/* Cleans up before exiting game */
void EndGame()
{
	if (buf1 != NULL) destroy_bitmap(buf1);
	if (buf2 != NULL) destroy_bitmap(buf2);
	if (bmp != NULL) destroy_bitmap(bmp);
	unload_datafile(data);
	allegro_exit();
}
/****************************************************************************/
void newmap()
{
	int x, y;

	pills = 0;

	for (y=0; y<=14; y++)
		for (x=0; x<=20; x++)
			map[y][x]=A000BLANK;

	map[14][1]=piece_index+15;
	map[14][2]=piece_index+16;
	map[14][3]=piece_index+16;
	map[14][4]=piece_index+17;
	for (x=5; x<=8; x++) map[14][x]=piece_index+13; /* LINE H / A00LINE14 */
	map[8][9]=piece_index+14; /* R */
	map[8][11]=piece_index+12; /* L */
	for (x=9; x<=11; x++) map[10][x]=piece_index+13;
}
/****************************************************************************/
void drawmap()
{
	int x, y;

	pills = 0;
	scare_mouse();

	/* Convert lines to current line type before drawing */
	for (y=0; y<=14; y++) {
		for (x=0; x<=20; x++) {
			if (map[y][x] < A99LINEZZ && map[y][x]>=A00LINE01) {
				if (map[y][x]<piece_index) map[y][x]+=19;
				else if (map[y][x]>piece_index+18) map[y][x]-=19;
			}
		}
	}

	for (y=0; y<=14; y++)
	{
		for (x=0; x<=20; x++)
		{
			blit(data[map[y][x]].dat, screen, 0, 0, x*15+159, y*15+134, 15, 15);
			if (map[y][x] >= A000PILL001 && map[y][x] < A000PPILLZZZ) pills++;
		}
	}
	if (grid==TRUE)
	{
		for (y=1; y<=14; y++) hline(screen, 159, y*15+134, 473, 248);
		for (x=1; x<=20; x++) vline(screen, x*15+159, 134, 358, 248);
	}
	unscare_mouse();
}
/****************************************************************************/
void savemap(void)
{
	PACKFILE *file;
	char text[256];   // temporarly used for storing map name

	strcpy(text, mapName);

	// do file dialog
	if (file_select("Save Map (*.map)", text, "map") == 0) 
		return;

	strcpy(mapName, text);

	packfile_password(NULL);

	// open the file in write binary mode
	file = pack_fopen(mapName, F_WRITE_PACKED);
	if (file==NULL)
	{
		alert("File could not be opened.", NULL, NULL, "Ok", NULL, KEY_ESC, KEY_ENTER);
		return;
	}

	// write file ID, version and pills
	pack_fwrite(MAP_ID, strlen(MAP_ID)+1, file);
	pack_fwrite(&MAP_VER, 1, file);
	pack_fwrite(&pills, 1, file);

	// write the map data
	pack_fwrite(&map, 315*4, file);   // 4 bytes per int, 315 pieces of map data

	// never forget to close the file
	pack_fclose(file);
	alert("MAP SAVED", NULL, mapName, "Ok", NULL, KEY_ESC, KEY_ENTER);
	saved = TRUE;
}
/****************************************************************************/
void loadmap(void)
{
	PACKFILE *file;
	char testID[7];            // used for testing the id
	unsigned char testVer;     // used for testing the version
   int x, y, p=0;

	char text[256];   // temporarly used for storing map name
	text[0] = '\0';   // we start with current directory


	// do file dialog
	if (file_select("Load Map (*.map)", text, "map") == 0) 
		return;

	packfile_password(NULL);

	// open file in read binary mode
	file = pack_fopen(text, F_READ_PACKED);
	if (file==NULL)
	{
		alert("File could not be opened.", NULL, NULL, "Ok", NULL, KEY_ESC, KEY_ENTER);
		return;
	}

	// read the id and version
	pack_fread(testID, strlen(MAP_ID)+1, file);
	pack_fread(&testVer, 1, file);

	// compare the ID and version
	if (testVer != MAP_VER || strcmp(testID, MAP_ID) != 0)
	{
		alert("Invalid map type or version.", NULL, NULL, "Ok",NULL, KEY_ESC, KEY_ENTER);
		pack_fclose(file);
		return;
	}

	// read the number of pills on the map
	pack_fread(&pills, 1, file);

	// read map data
	pack_fread(&map, 315*4, file);
	pack_fclose(file);

	
   // set the piece_index to the first line of the set this map uses.
	for (y=0; y<15; y++) {
		for (x=0; x<21; x++) {
			if (map[y][x]>=A00LINE01 && map[y][x]<A99LINEZZ) {
            if (piece >= A00LINE01) p = piece - piece_index;
            piece_index = ((int)(map[y][x]-23)/19)*19+23;
            if (piece >= A00LINE01) piece = piece_index + p;
            x=21; y=15;
			}
		}
	}

	strcpy(mapName, text);
}

/****************************************************************************/
int Continue(void)
{
	int exit=0, k;

	clear_keybuf();
	do {
		if (keypressed())
		{
			k = readkey();
			if ((k >> 8) == KEY_F12) save_screen();
			exit=1;
		}
		if (mouse_b & 1) exit=2;
	} while(exit==0);
	clear_keybuf();

	return exit;
}

/****************************************************************************/
void draw_pieces()
{
	int x, y, index;

	scare_mouse();

	/*** Draw lines on screen ***/
	x=20; y=80;
	for (index=piece_index; index<piece_index+18; index++) {
		stretch_blit(data[index].dat, screen, 0, 0, 15, 15, x, y, 30, 30);
		x+=45;
		if (x>110) {
			x=20;
			y+=45;
		}
	}
	stretch_blit(data[index].dat, screen, 0, 0, 15, 15, x+45, y, 30, 30);

	x=493; y=80;
	for (index=A000PILL001; index<A000PPILLZZZ; index++) {
		stretch_blit(data[index].dat, screen, 0, 0, 15, 15, x, y, 30, 30);
		x+=45;
		if (x>610) {
			x=493;
			y+=45;
		}
	}

	unscare_mouse();
}

/****************************************************************************/
int main(int argc, char *argv[])
{
   int gx=0, gy=0;
	int done=FALSE;
	int x, y, ox, oy;
	int ogx=-1, ogy=-1, opiece=0;

	strcpy(path, argv[0]);
	strcpy(text, path);
   strcpy(get_filename(text), "DPacman.dat");

	init();

	set_palette(data[PAL_DEFAULT].dat);
	set_mouse_sprite(NULL);  // restore the mouse colors
	text_mode(252);

	scare_mouse();
	/*** Load editing screen here ***/
	blit(data[PACEMAIN].dat, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
	unscare_mouse();

	draw_pieces();
	show_mouse(screen);
	newmap();
	drawmap();

	x=19; y=79; ox=x; oy=y;
	scare_mouse(); rect(screen, x, y, x+31, y+31, 240); unscare_mouse();
	while(!done)
	{
		if (mouse_x > 159 && mouse_x < 473 && 
			 mouse_y > 134 && mouse_y < 358)
		{
         gx=(mouse_x-159)/15;
         gy=(mouse_y-134)/15;
         if (sprite!=data[piece].dat) {
            sprite=data[piece].dat;
            setsprite=TRUE;
            spritex=sprite->w>>1;
            spritey=sprite->h>>1;
         }
		}
		else if (sprite!=NULL) {
			sprite=NULL;
			setsprite=TRUE;
			spritex=0;
			spritey=0;
		}
		if (setsprite) {
			scare_mouse();
			set_mouse_sprite(sprite);
			setsprite=FALSE;
			set_mouse_sprite_focus(spritex, spritey);
			unscare_mouse();
		}
		text_mode(252);
		textprintf(screen, font, 2, 470, 0, " X:%2d   Y:%2d   PILLS:%2d ", gx, gy, pills);

		/*** check for mouse clicks and respond ***/
	  if (mouse_b & 1) {    //left mouse button
			if (mouse_x > 159 && mouse_x < 474 &&
				 mouse_y > 134 && mouse_y < 358) {
				if (ogx!=gx || ogy!=gy || opiece!=piece) {
					if (!(gy==9 && (gx>=9 && gx<=11)) &&
						 !(gy==11 && gx==10)) {
						map[gy][gx] = piece;
					}
					saved = FALSE;
					drawmap();
					ogx=gx; ogy=gy; opiece=piece;
				}
			}
			if (mouse_y > 79 && mouse_y < 111) {
				/* line */
				if (mouse_x > 19 && mouse_x < 51) {
					piece = piece_index; ox=x; oy=y; x=19; y=79;
				}
				if (mouse_x > 64 && mouse_x < 96) {
					piece = piece_index + 1; ox=x; oy=y; x=64; y=79;
				}
				if (mouse_x > 109 && mouse_x < 141) {
					piece = piece_index + 2; ox=x; oy=y; x=109; y=79;
				}
				/* pill */
				if (mouse_x > 492 && mouse_x < 524) {
					piece = A000PILL001; ox=x; oy=y; x=492; y=79;
				}
				if (mouse_x > 537 && mouse_x < 569) {
					piece = A000PILL001+1; ox=x; oy=y; x=537; y=79;
				}
				if (mouse_x > 582 && mouse_x < 614) {
					piece = A000PILL001+2; ox=x; oy=y; x=582; y=79;
				}
			}
			if (mouse_y > 124 && mouse_y < 156) {
				/* line */
				if (mouse_x > 19 && mouse_x < 51) {
					piece = piece_index + 3; ox=x; oy=y; x=19; y=124;
				}
				if (mouse_x > 64 && mouse_x < 96) {
					piece = piece_index + 4; ox=x; oy=y; x=64; y=124;
				}
				if (mouse_x > 109 && mouse_x < 141) {
					piece = piece_index + 5; ox=x; oy=y; x=109; y=124;
				}
				/* pill */
				if (mouse_x > 492 && mouse_x < 524) {
					piece = A000PILL001+3; ox=x; oy=y; x=492; y=124;
				}
				if (mouse_x > 537 && mouse_x < 569) {
					piece = A000PILL001+4; ox=x; oy=y; x=537; y=124;
				}
				if (mouse_x > 582 && mouse_x < 614) {
					piece = A000PILL001+5; ox=x; oy=y; x=582; y=124;
				}
			}
			if (mouse_y > 169 && mouse_y < 201) {
				/* line */
				if (mouse_x > 19 && mouse_x < 51) {
					piece = piece_index + 6; ox=x; oy=y; x=19; y=169;
				}
				if (mouse_x > 64 && mouse_x < 96) {
					piece = piece_index + 7; ox=x; oy=y; x=64; y=169;
				}
				if (mouse_x > 109 && mouse_x < 141) {
					piece = piece_index + 8; ox=x; oy=y; x=109; y=169;
				}
				/* pill */
				if (mouse_x > 492 && mouse_x < 524) {
					piece = A000PILL001+6; ox=x; oy=y; x=492; y=169;
				}
				if (mouse_x > 537 && mouse_x < 569) {
					piece = A000PILL001+7; ox=x; oy=y; x=537; y=169;
				}
				if (mouse_x > 582 && mouse_x < 614) {
					piece = A000PILL001+8; ox=x; oy=y; x=582; y=169;
				}
			}
			if (mouse_y > 214 && mouse_y < 246) {
				/* line */
				if (mouse_x > 19 && mouse_x < 51) {
					piece = piece_index + 9; ox=x; oy=y; x=19; y=214;
				}
				if (mouse_x > 64 && mouse_x < 96) {
					piece = piece_index + 10; ox=x; oy=y; x=64; y=214;
				}
				if (mouse_x > 109 && mouse_x < 141) {
					piece = piece_index + 11; ox=x; oy=y; x=109; y=214;
				}
				/* pill */
				if (mouse_x > 492 && mouse_x < 524) {
					piece = A000PILL001+9; ox=x; oy=y; x=492; y=214;
				}
				if (mouse_x > 537 && mouse_x < 569) {
					piece = A000PILL001+10; ox=x; oy=y; x=537; y=214;
				}
				if (mouse_x > 582 && mouse_x < 614) {
					piece = A000PILL001+11; ox=x; oy=y; x=582; y=214;
				}
			}
			if (mouse_y > 259 && mouse_y < 291) {
				/* line */
				if (mouse_x > 19 && mouse_x < 51) {
					piece = piece_index + 12; ox=x; oy=y; x=19; y=259;
				}
				if (mouse_x > 64 && mouse_x < 96) {
					piece = piece_index + 13; ox=x; oy=y; x=64; y=259;
				}
				if (mouse_x > 109 && mouse_x < 141) {
					piece = piece_index + 14; ox=x; oy=y; x=109; y=259;
				}
				/* pill */
				if (mouse_x > 492 && mouse_x < 524) {
					piece = A000PILL001+12; ox=x; oy=y; x=492; y=259;
				}
				if (mouse_x > 537 && mouse_x < 569) {
					piece = A000PILL001+13; ox=x; oy=y; x=537; y=259;
				}
				if (mouse_x > 582 && mouse_x < 614) {
					piece = A000PILL001+14; ox=x; oy=y; x=582; y=259;
				}
			}
			if (mouse_y > 304 && mouse_y < 336) {
				/* line */
				if (mouse_x > 19 && mouse_x < 51) {
					piece = piece_index + 15; ox=x; oy=y; x=19; y=304;
				}
				if (mouse_x > 64 && mouse_x < 96) {
					piece = piece_index + 16; ox=x; oy=y; x=64; y=304;
				}
				if (mouse_x > 109 && mouse_x < 141) {
					piece = piece_index + 17; ox=x; oy=y; x=109; y=304;
				}
				/* pill */
				if (mouse_x > 492 && mouse_x < 524) {
					piece = A000PILL001+15; ox=x; oy=y; x=492; y=304;
				}
				if (mouse_x > 537 && mouse_x < 569) {
					piece = A000PILL001+16; ox=x; oy=y; x=537; y=304;
				}
				if (mouse_x > 582 && mouse_x < 614) {
					piece = A000PILL001+17; ox=x; oy=y; x=582; y=304;
				}
			}
			if (mouse_y > 349 && mouse_y < 381) {
				/* line & arrow buttons */
				if (mouse_x > 19 && mouse_x < 51) {
               if (piece >= A00LINE01) piece = piece - piece_index;
               piece_index-=19;
					if (piece_index<A00LINE01) piece_index=A00LINE01;
               if (piece >= A00LINE01) piece = piece_index + piece;
					drawmap();
					draw_pieces();
				}
				if (mouse_x > 64 && mouse_x < 96) {
					piece = piece_index + 18; ox=x; oy=y; x=64; y=349;
				}
				if (mouse_x > 109 && mouse_x < 141) {
               if (piece >= A00LINE01) piece = piece - piece_index;
					piece_index+=19;
					if (piece_index>=A99LINEZZ) piece_index-=19;
               if (piece >= A00LINE01) piece = piece_index + piece;
					drawmap();
					draw_pieces();
				}
				/* pill */
				if (mouse_x > 492 && mouse_x < 524) {
					piece = A000PILL001+18; ox=x; oy=y; x=492; y=349;
				}
				if (mouse_x > 537 && mouse_x < 569) {
					piece = A000PILL001+19; ox=x; oy=y; x=537; y=349;
				}
				if (mouse_x > 582 && mouse_x < 614) {
					piece = A000PILL001+20; ox=x; oy=y; x=582; y=349;
				}
			}

			if (mouse_y >= 372 && mouse_y <= 401 &&
				 mouse_x >= 285 && mouse_x <= 354)  simulate_keypress(KEY_G<<8);

			if (mouse_y >= 411 && mouse_y <= 442) {
				if (mouse_x >= 169 && mouse_x <= 233) simulate_keypress(KEY_N<<8);
				if (mouse_x >= 243 && mouse_x <= 316) simulate_keypress(KEY_L<<8);
				if (mouse_x >= 326 && mouse_x <= 396) simulate_keypress(KEY_S<<8);
				if (mouse_x >= 406 && mouse_x <= 471) simulate_keypress(KEY_Q<<8);
			}
			
			scare_mouse();
			rect(screen, ox, oy, ox+31, oy+31, 247);
			rect(screen, x, y, x+31, y+31, 240);
			unscare_mouse();
			rest(200);
		}

		if (mouse_b & 2)   //right mouse button (blank piece)
		{
			if (mouse_x > 159 && mouse_x < 474 && mouse_y > 134 && mouse_y < 358)
			{
				if (ogx!=gx || ogy!=gy || opiece!=A000BLANK)
				{
					map[gy][gx] = A000BLANK;
					saved = FALSE;
					drawmap();
					ogx=gx; ogy=gy; opiece=A000BLANK;
				}
			}
		}

		if (keypressed())
		{
			// what key was pressed ?
			switch((readkey() >> 8))
			{
				case KEY_Q: // quit editor
					{ play_sample(data[SS_TYPE].dat, 255, 128, 1000, 0);
					  rest(200);
					  if (saved) done=TRUE;
					  else if (alert("CHANGES NOT SAVED YET", NULL, "Are you sure?", "Ok", "Cancel", KEY_ENTER, KEY_ESC) == 1) done = TRUE;
					} break;
				case KEY_G: //toggle grid on/off
					{  play_sample(data[SS_TYPE].dat, 255, 128, 1000, 0);
						if (grid==TRUE) grid=FALSE;
						else grid=TRUE;
						drawmap();
					} break;
				case KEY_N: //New map
					{  play_sample(data[SS_TYPE].dat, 255, 128, 1000, 0);
						newmap();
						gx=0; ogx=-1;
						gy=0; ogy=-1;
						drawmap();
					} break;
				case KEY_L: //Load map
					{  play_sample(data[SS_TYPE].dat, 255, 128, 1000, 0);
						loadmap();
						drawmap();
                  draw_pieces();
               } break;
				case KEY_S: //Save map
					{  play_sample(data[SS_TYPE].dat, 255, 128, 1000, 0);
						savemap();
						drawmap();
					} break;
				case KEY_F12: //Screen dump
					{  play_sample(data[SS_TYPE].dat, 255, 128, 1000, 0);
						save_screen();
						alert("SCREEN SAVED", NULL, NULL, "Ok", NULL, KEY_ENTER, KEY_ESC);
					} break;

			}  //end switch
		}  //end if
	}  //end while

	show_mouse(NULL);
	EndGame();
	return 0;
}
END_OF_MAIN();
